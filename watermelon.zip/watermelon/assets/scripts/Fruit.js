cc.Class({
    extends: cc.Component,

    properties: {
        id: 0,
        collisionEndY: -1000,
        deadlineY: 310,
    },

    init(data) {
        this.id = data.id;
        const sp = this.node.getComponent(cc.Sprite);
        sp.spriteFrame = data.iconSF;
    },
    start() {
    },
    onCollisionEnter(other, self) {
        console.log("触发碰撞检测");
        console.log("碰撞物体: ", other.node.name);
    },

    onCollisionExit(other, self) {
        if (other.node.name === 'dead_line') {
            // 记录碰撞结束时的 y 坐标（水果的底部中点）
            this.collisionEndY = this.node.y;
            console.log("y坐标",this.node.y);
        }
    },
    update(dt) {
        // 使用 this 关键字来访问类的属性
        if (this.collisionEndY >= this.deadlineY) {
            console.log("水果在碰撞结束后超过了死区，游戏结束");
            cc.director.loadScene('end'); // 加载结束场景
        }
    },
    onBeginContact(contact, self, other) {  
        if (self.node && other.node) {  
            const s = self.node.getComponent('Fruit');  
            const o = other.node.getComponent('Fruit');  
            if (s && o && s.id === o.id) {  
                self.node.emit('sameContact', {self, other});  
            }  
        }  
    },  
 
});