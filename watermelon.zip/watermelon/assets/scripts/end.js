
cc.Class({
    extends: cc.Component,

    properties: {
     
    },

    toEnd(e,c){
    cc.game.end();
},

    start () {

    },

    // update (dt) {},
});
