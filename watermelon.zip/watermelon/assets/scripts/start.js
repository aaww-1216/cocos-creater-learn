cc.Class({
    extends: cc.Component,

    properties: {

    },

    // 点击事件回调函数
    toStart(e, c){

        cc.director.loadScene('game')
    },

    start () {


}
});
