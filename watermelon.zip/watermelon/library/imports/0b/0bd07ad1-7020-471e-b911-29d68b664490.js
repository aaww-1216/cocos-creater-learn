"use strict";
cc._RF.push(module, '0bd07rRcCBHHrkRKdaLZkSQ', 'start');
// scripts/start.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // 点击事件回调函数
  toStart: function toStart(e, c) {
    cc.director.loadScene('game');
  },
  start: function start() {}
});

cc._RF.pop();