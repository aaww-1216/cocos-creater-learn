"use strict";
cc._RF.push(module, '365b4UAiQRBA7QXa2IuFMmj', 'Fruit');
// scripts/Fruit.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    id: 0,
    collisionEndY: -1000,
    deadlineY: 310
  },
  init: function init(data) {
    this.id = data.id;
    var sp = this.node.getComponent(cc.Sprite);
    sp.spriteFrame = data.iconSF;
  },
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log("触发碰撞检测");
    console.log("碰撞物体: ", other.node.name); // 如果碰撞物体是 'dead_line'，我们不需要在这里做特殊处理，因为我们在 onCollisionExit 中处理
  },
  onCollisionExit: function onCollisionExit(other, self) {
    if (other.node.name === 'dead_line') {
      // 记录碰撞结束时的 y 坐标（水果的底部中点）
      this.collisionEndY = this.node.y;
      console.log("y坐标", this.node.y);
    }
  },
  update: function update(dt) {
    // 使用 this 关键字来访问类的属性
    if (this.collisionEndY >= this.deadlineY) {
      console.log("水果在碰撞结束后超过了死区，游戏结束");
      cc.director.loadScene('end'); // 加载结束场景
    }
  },
  onBeginContact: function onBeginContact(contact, self, other) {
    if (self.node && other.node) {
      var s = self.node.getComponent('Fruit');
      var o = other.node.getComponent('Fruit');

      if (s && o && s.id === o.id) {
        self.node.emit('sameContact', {
          self: self,
          other: other
        });
      }
    }
  } // 注意：onBeginContact 不是 Cocos Creator 标准物理回调方法
  // 如果您想要处理两个水果之间的相同 ID 碰撞，您可能需要使用其他方法
  // 比如，在 onCollisionEnter 中检查两个水果的 ID，并设置一个标志位或触发一个事件
  // 这里我们移除了 onBeginContact 方法，因为它不是物理系统的一部分

});

cc._RF.pop();