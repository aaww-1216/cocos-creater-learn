"use strict";
cc._RF.push(module, '8e80dMWyH5LD7Oj100K42f8', 'Game');
// scripts/Game.js

"use strict";

var Fruit = cc.Class({
  name: 'FruitItem',
  properties: {
    id: 0,
    iconSF: cc.SpriteFrame
  }
});
var JuiceItem = cc.Class({
  name: 'JuiceItem',
  properties: {
    particle: cc.SpriteFrame,
    circle: cc.SpriteFrame,
    slash: cc.SpriteFrame
  }
});
var MAX_HEIGHT = -300;
cc.Class({
  "extends": cc.Component,
  properties: {
    fruits: {
      "default": [],
      type: Fruit
    },
    juices: {
      "default": [],
      type: JuiceItem
    },
    fruitPrefab: {
      "default": null,
      type: cc.Prefab
    },
    juicePrefab: {
      "default": null,
      type: cc.Prefab
    },
    boomAudio: {
      "default": null,
      type: cc.AudioClip
    },
    knockAudio: {
      "default": null,
      type: cc.AudioClip
    },
    waterAudio: {
      "default": null,
      type: cc.AudioClip
    },
    scoreLabel: {
      "default": null,
      type: cc.Label
    },
    dead_line: cc.Node,
    collisionCount: 0 // 添加碰撞计数器  

  },
  onLoad: function onLoad() {
    this.initPhysics();
    cc.director.getCollisionManager().enabled = true;
    this.isCreating = false;
    this.fruitCount = 0;
    this.score = 0;
    this.node.on(cc.Node.EventType.MOUSE_DOWN, this.onTouchStart, this); // this.node.on(cc.Node.EventType.MOUSE_MOVE, this.onTouchMove, this);  

    this.node.on(cc.Node.EventType.MOUSE_UP, this.onTouchEnd, this); // this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);  
    // this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);  
    // this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);  
    // this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);  

    this.initOneFruit();
    var collider = this.node.getComponent(cc.Collider);

    if (collider) {
      collider.on(cc.Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
      collider.on(cc.Contact2DType.END_CONTACT, this.onEndContact, this);
    } // 注册全局碰撞回调函数  
    // if (cc.PhysicsSystem2D.instance) {  
    //     cc.PhysicsSystem2D.instance.on(cc.Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);  
    //     cc.PhysicsSystem2D.instance.on(cc.Contact2DType.END_CONTACT, this.onEndContact, this);  
    // }  

  },
  // onCollisionEnter(other,self,contact) {  
  //     console.log("触发检测启动");  
  //     console.log("碰撞检测: ", other.node.name);  
  //     if (other.node.name === "Dead_line") {  
  //         const gameController = cc.find('GameController').getComponent('你的游戏控制脚本');  
  //         gameController.collisionCount++;   
  //         console.log("碰撞次数: " + gameController.collisionCount);  
  //         if (gameController.collisionCount >= 2) {  
  //             gameController.endGame();   
  //         }  
  //     }  
  // },
  initPhysics: function initPhysics() {
    var instance = cc.director.getPhysicsManager();
    instance.enabled = true;
    instance.gravity = cc.v2(0, -300);
    var collisionManager = cc.director.getCollisionManager();
    collisionManager.enabled = true;
    var width = this.node.width;
    var height = this.node.height;
    var node = new cc.Node();
    var body = node.addComponent(cc.RigidBody);
    body.type = cc.RigidBodyType.Static;

    var _addBound = function _addBound(node, x, y, width, height) {
      var collider = node.addComponent(cc.PhysicsBoxCollider);
      collider.offset.x = x;
      collider.offset.y = y;
      collider.size.width = width;
      collider.size.height = height;
    };

    _addBound(node, 0, -height / 2, width, 1);

    _addBound(node, 0, height / 2, width, 1);

    _addBound(node, -width / 2, 0, 1, height);

    _addBound(node, width / 2, 0, 1, height);

    node.parent = this.node;
  },
  initOneFruit: function initOneFruit(id) {
    if (id === void 0) {
      id = 1;
    }

    this.fruitCount++;
    this.currentFruit = this.createFruitOnPos(0, 340, id);
  },
  onTouchStart: function onTouchStart(e) {
    var _this = this;

    if (this.isCreating) return;
    this.isCreating = true;
    var _this$node = this.node,
        width = _this$node.width,
        height = _this$node.height;
    var fruit = this.currentFruit;
    var pos = e.getLocation();
    var x = pos.x,
        y = pos.y;
    x = (x - width / 2) * 1.5;
    y = (y - height / 2) * 1.5;
    var action = cc.sequence(cc.moveBy(0.3, cc.v2(x, 0)).easing(cc.easeCubicActionIn()), cc.callFunc(function () {
      _this.startFruitPhysics(fruit);

      _this.scheduleOnce(function () {
        var nextId = _this.getNextFruitId();

        _this.initOneFruit(nextId);

        _this.isCreating = false;
      }, 1);
    }));
    fruit.runAction(action);
  },
  onTouchEnd: function onTouchEnd(e) {
    var _this2 = this;

    this.scheduleOnce(function () {
      if (_this2.currentFruit) {
        // 设置当前水果为正在下落状态  
        _this2.currentFruit.getComponent('Fruit').isFalling = true;
        _this2.currentFruit.getComponent('Fruit').fallStartTime = Date.now(); // 记录开始下落的时间  
      }
    }, 0.8); // 在 0.8 秒后设置下落状态  
  },
  getNextFruitId: function getNextFruitId() {
    if (this.fruitCount < 3) {
      return 1;
    } else if (this.fruitCount === 3) {
      return 2;
    } else {
      // 随机返回前5个
      return Math.floor(Math.random() * 5) + 1;
    }
  },
  createOneFruit: function createOneFruit(num) {
    var fruit = cc.instantiate(this.fruitPrefab);
    var config = this.fruits[num - 1];
    fruit.getComponent('Fruit').init({
      id: config.id,
      iconSF: config.iconSF
    });
    fruit.getComponent(cc.RigidBody).type = cc.RigidBodyType.Static;
    fruit.getComponent(cc.PhysicsCircleCollider).radius = 0;
    this.node.addChild(fruit);
    fruit.scale = 0.6;
    fruit.on('sameContact', this.onSameFruitContact.bind(this));
    return fruit;
  },
  startFruitPhysics: function startFruitPhysics(fruit) {
    fruit.getComponent(cc.RigidBody).type = cc.RigidBodyType.Dynamic;
    var physicsCircleCollider = fruit.getComponent(cc.PhysicsCircleCollider);
    physicsCircleCollider.radius = fruit.height / 2;
    physicsCircleCollider.apply();
  },
  // 在指定位置生成水果
  createFruitOnPos: function createFruitOnPos(x, y, type) {
    if (type === void 0) {
      type = 1;
    }

    var fruit = this.createOneFruit(type);
    fruit.setPosition(cc.v2(x, y));
    return fruit;
  },
  // 两个水果碰撞
  onSameFruitContact: function onSameFruitContact(_ref) {
    var self = _ref.self,
        other = _ref.other;
    other.node.off('sameContact'); // 两个node都会触发，todo 看看有没有其他方法只展示一次的

    var id = other.getComponent('Fruit').id; // todo 可以使用对象池回收

    self.node.removeFromParent(true);
    other.node.removeFromParent(true);
    var _other$node = other.node,
        x = _other$node.x,
        y = _other$node.y;
    this.createFruitJuice(id, cc.v2({
      x: x,
      y: y
    }), other.node.width);
    this.addScore(id);
    var nextId = id + 1;

    if (nextId <= 11) {
      var newFruit = this.createFruitOnPos(x, y, nextId);
      this.startFruitPhysics(newFruit); // 展示动画 todo 动画效果需要调整

      newFruit.scale = 0;
      cc.tween(newFruit).to(.5, {
        scale: 0.6
      }, {
        easing: "backOut"
      }).start();
    }
  },
  createFruitJuice: function createFruitJuice(id, pos, n) {
    cc.audioEngine.play(this.boomAudio, false, 1);
    cc.audioEngine.play(this.waterAudio, false, 1);
    var juice = cc.instantiate(this.juicePrefab);
    this.node.addChild(juice);
    var config = this.juices[id - 1];
    var instance = juice.getComponent('Juice');
    instance.init(config);
    instance.showJuice(pos, n);
  },
  addScore: function addScore(fruitId) {
    this.score += fruitId * 2;
    this.scoreLabel.string = this.score;
  },
  endGame: function endGame() {
    this.node.pauseAllActions(); // 暂停当前节点的所有动作  

    cc.director.loadScene('end'); // 你可以在这里添加代码来显示游戏结束界面或做其他处理  
  }
});

cc._RF.pop();