"use strict";
cc._RF.push(module, 'f5d1cWqNEZCtZBXic8+4t+/', 'end');
// scripts/end.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  toEnd: function toEnd(e, c) {
    cc.game.end();
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();