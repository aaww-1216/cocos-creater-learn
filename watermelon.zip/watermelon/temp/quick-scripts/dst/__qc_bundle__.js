
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/scripts/Fruit');
require('./assets/scripts/Game');
require('./assets/scripts/Juice');
require('./assets/scripts/end');
require('./assets/scripts/start');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8e80dMWyH5LD7Oj100K42f8', 'Game');
// scripts/Game.js

"use strict";

var Fruit = cc.Class({
  name: 'FruitItem',
  properties: {
    id: 0,
    iconSF: cc.SpriteFrame
  }
});
var JuiceItem = cc.Class({
  name: 'JuiceItem',
  properties: {
    particle: cc.SpriteFrame,
    circle: cc.SpriteFrame,
    slash: cc.SpriteFrame
  }
});
var MAX_HEIGHT = -300;
cc.Class({
  "extends": cc.Component,
  properties: {
    fruits: {
      "default": [],
      type: Fruit
    },
    juices: {
      "default": [],
      type: JuiceItem
    },
    fruitPrefab: {
      "default": null,
      type: cc.Prefab
    },
    juicePrefab: {
      "default": null,
      type: cc.Prefab
    },
    boomAudio: {
      "default": null,
      type: cc.AudioClip
    },
    knockAudio: {
      "default": null,
      type: cc.AudioClip
    },
    waterAudio: {
      "default": null,
      type: cc.AudioClip
    },
    scoreLabel: {
      "default": null,
      type: cc.Label
    },
    dead_line: cc.Node,
    collisionCount: 0 // 添加碰撞计数器  

  },
  onLoad: function onLoad() {
    this.initPhysics();
    cc.director.getCollisionManager().enabled = true;
    this.isCreating = false;
    this.fruitCount = 0;
    this.score = 0;
    this.node.on(cc.Node.EventType.MOUSE_DOWN, this.onTouchStart, this); // this.node.on(cc.Node.EventType.MOUSE_MOVE, this.onTouchMove, this);  

    this.node.on(cc.Node.EventType.MOUSE_UP, this.onTouchEnd, this); // this.node.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);  
    // this.node.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);  
    // this.node.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);  
    // this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.onTouchCancel, this);  

    this.initOneFruit();
    var collider = this.node.getComponent(cc.Collider);

    if (collider) {
      collider.on(cc.Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);
      collider.on(cc.Contact2DType.END_CONTACT, this.onEndContact, this);
    } // 注册全局碰撞回调函数  
    // if (cc.PhysicsSystem2D.instance) {  
    //     cc.PhysicsSystem2D.instance.on(cc.Contact2DType.BEGIN_CONTACT, this.onBeginContact, this);  
    //     cc.PhysicsSystem2D.instance.on(cc.Contact2DType.END_CONTACT, this.onEndContact, this);  
    // }  

  },
  // onCollisionEnter(other,self,contact) {  
  //     console.log("触发检测启动");  
  //     console.log("碰撞检测: ", other.node.name);  
  //     if (other.node.name === "Dead_line") {  
  //         const gameController = cc.find('GameController').getComponent('你的游戏控制脚本');  
  //         gameController.collisionCount++;   
  //         console.log("碰撞次数: " + gameController.collisionCount);  
  //         if (gameController.collisionCount >= 2) {  
  //             gameController.endGame();   
  //         }  
  //     }  
  // },
  initPhysics: function initPhysics() {
    var instance = cc.director.getPhysicsManager();
    instance.enabled = true;
    instance.gravity = cc.v2(0, -300);
    var collisionManager = cc.director.getCollisionManager();
    collisionManager.enabled = true;
    var width = this.node.width;
    var height = this.node.height;
    var node = new cc.Node();
    var body = node.addComponent(cc.RigidBody);
    body.type = cc.RigidBodyType.Static;

    var _addBound = function _addBound(node, x, y, width, height) {
      var collider = node.addComponent(cc.PhysicsBoxCollider);
      collider.offset.x = x;
      collider.offset.y = y;
      collider.size.width = width;
      collider.size.height = height;
    };

    _addBound(node, 0, -height / 2, width, 1);

    _addBound(node, 0, height / 2, width, 1);

    _addBound(node, -width / 2, 0, 1, height);

    _addBound(node, width / 2, 0, 1, height);

    node.parent = this.node;
  },
  initOneFruit: function initOneFruit(id) {
    if (id === void 0) {
      id = 1;
    }

    this.fruitCount++;
    this.currentFruit = this.createFruitOnPos(0, 340, id);
  },
  onTouchStart: function onTouchStart(e) {
    var _this = this;

    if (this.isCreating) return;
    this.isCreating = true;
    var _this$node = this.node,
        width = _this$node.width,
        height = _this$node.height;
    var fruit = this.currentFruit;
    var pos = e.getLocation();
    var x = pos.x,
        y = pos.y;
    x = (x - width / 2) * 1.5;
    y = (y - height / 2) * 1.5;
    var action = cc.sequence(cc.moveBy(0.3, cc.v2(x, 0)).easing(cc.easeCubicActionIn()), cc.callFunc(function () {
      _this.startFruitPhysics(fruit);

      _this.scheduleOnce(function () {
        var nextId = _this.getNextFruitId();

        _this.initOneFruit(nextId);

        _this.isCreating = false;
      }, 1);
    }));
    fruit.runAction(action);
  },
  onTouchEnd: function onTouchEnd(e) {
    var _this2 = this;

    this.scheduleOnce(function () {
      if (_this2.currentFruit) {
        // 设置当前水果为正在下落状态  
        _this2.currentFruit.getComponent('Fruit').isFalling = true;
        _this2.currentFruit.getComponent('Fruit').fallStartTime = Date.now(); // 记录开始下落的时间  
      }
    }, 0.8); // 在 0.8 秒后设置下落状态  
  },
  getNextFruitId: function getNextFruitId() {
    if (this.fruitCount < 3) {
      return 1;
    } else if (this.fruitCount === 3) {
      return 2;
    } else {
      // 随机返回前5个
      return Math.floor(Math.random() * 5) + 1;
    }
  },
  createOneFruit: function createOneFruit(num) {
    var fruit = cc.instantiate(this.fruitPrefab);
    var config = this.fruits[num - 1];
    fruit.getComponent('Fruit').init({
      id: config.id,
      iconSF: config.iconSF
    });
    fruit.getComponent(cc.RigidBody).type = cc.RigidBodyType.Static;
    fruit.getComponent(cc.PhysicsCircleCollider).radius = 0;
    this.node.addChild(fruit);
    fruit.scale = 0.6;
    fruit.on('sameContact', this.onSameFruitContact.bind(this));
    return fruit;
  },
  startFruitPhysics: function startFruitPhysics(fruit) {
    fruit.getComponent(cc.RigidBody).type = cc.RigidBodyType.Dynamic;
    var physicsCircleCollider = fruit.getComponent(cc.PhysicsCircleCollider);
    physicsCircleCollider.radius = fruit.height / 2;
    physicsCircleCollider.apply();
  },
  // 在指定位置生成水果
  createFruitOnPos: function createFruitOnPos(x, y, type) {
    if (type === void 0) {
      type = 1;
    }

    var fruit = this.createOneFruit(type);
    fruit.setPosition(cc.v2(x, y));
    return fruit;
  },
  // 两个水果碰撞
  onSameFruitContact: function onSameFruitContact(_ref) {
    var self = _ref.self,
        other = _ref.other;
    other.node.off('sameContact'); // 两个node都会触发，todo 看看有没有其他方法只展示一次的

    var id = other.getComponent('Fruit').id; // todo 可以使用对象池回收

    self.node.removeFromParent(true);
    other.node.removeFromParent(true);
    var _other$node = other.node,
        x = _other$node.x,
        y = _other$node.y;
    this.createFruitJuice(id, cc.v2({
      x: x,
      y: y
    }), other.node.width);
    this.addScore(id);
    var nextId = id + 1;

    if (nextId <= 11) {
      var newFruit = this.createFruitOnPos(x, y, nextId);
      this.startFruitPhysics(newFruit); // 展示动画 todo 动画效果需要调整

      newFruit.scale = 0;
      cc.tween(newFruit).to(.5, {
        scale: 0.6
      }, {
        easing: "backOut"
      }).start();
    }
  },
  createFruitJuice: function createFruitJuice(id, pos, n) {
    cc.audioEngine.play(this.boomAudio, false, 1);
    cc.audioEngine.play(this.waterAudio, false, 1);
    var juice = cc.instantiate(this.juicePrefab);
    this.node.addChild(juice);
    var config = this.juices[id - 1];
    var instance = juice.getComponent('Juice');
    instance.init(config);
    instance.showJuice(pos, n);
  },
  addScore: function addScore(fruitId) {
    this.score += fruitId * 2;
    this.scoreLabel.string = this.score;
  },
  endGame: function endGame() {
    this.node.pauseAllActions(); // 暂停当前节点的所有动作  

    cc.director.loadScene('end'); // 你可以在这里添加代码来显示游戏结束界面或做其他处理  
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcR2FtZS5qcyJdLCJuYW1lcyI6WyJGcnVpdCIsImNjIiwiQ2xhc3MiLCJuYW1lIiwicHJvcGVydGllcyIsImlkIiwiaWNvblNGIiwiU3ByaXRlRnJhbWUiLCJKdWljZUl0ZW0iLCJwYXJ0aWNsZSIsImNpcmNsZSIsInNsYXNoIiwiTUFYX0hFSUdIVCIsIkNvbXBvbmVudCIsImZydWl0cyIsInR5cGUiLCJqdWljZXMiLCJmcnVpdFByZWZhYiIsIlByZWZhYiIsImp1aWNlUHJlZmFiIiwiYm9vbUF1ZGlvIiwiQXVkaW9DbGlwIiwia25vY2tBdWRpbyIsIndhdGVyQXVkaW8iLCJzY29yZUxhYmVsIiwiTGFiZWwiLCJkZWFkX2xpbmUiLCJOb2RlIiwiY29sbGlzaW9uQ291bnQiLCJvbkxvYWQiLCJpbml0UGh5c2ljcyIsImRpcmVjdG9yIiwiZ2V0Q29sbGlzaW9uTWFuYWdlciIsImVuYWJsZWQiLCJpc0NyZWF0aW5nIiwiZnJ1aXRDb3VudCIsInNjb3JlIiwibm9kZSIsIm9uIiwiRXZlbnRUeXBlIiwiTU9VU0VfRE9XTiIsIm9uVG91Y2hTdGFydCIsIk1PVVNFX1VQIiwib25Ub3VjaEVuZCIsImluaXRPbmVGcnVpdCIsImNvbGxpZGVyIiwiZ2V0Q29tcG9uZW50IiwiQ29sbGlkZXIiLCJDb250YWN0MkRUeXBlIiwiQkVHSU5fQ09OVEFDVCIsIm9uQmVnaW5Db250YWN0IiwiRU5EX0NPTlRBQ1QiLCJvbkVuZENvbnRhY3QiLCJpbnN0YW5jZSIsImdldFBoeXNpY3NNYW5hZ2VyIiwiZ3Jhdml0eSIsInYyIiwiY29sbGlzaW9uTWFuYWdlciIsIndpZHRoIiwiaGVpZ2h0IiwiYm9keSIsImFkZENvbXBvbmVudCIsIlJpZ2lkQm9keSIsIlJpZ2lkQm9keVR5cGUiLCJTdGF0aWMiLCJfYWRkQm91bmQiLCJ4IiwieSIsIlBoeXNpY3NCb3hDb2xsaWRlciIsIm9mZnNldCIsInNpemUiLCJwYXJlbnQiLCJjdXJyZW50RnJ1aXQiLCJjcmVhdGVGcnVpdE9uUG9zIiwiZSIsImZydWl0IiwicG9zIiwiZ2V0TG9jYXRpb24iLCJhY3Rpb24iLCJzZXF1ZW5jZSIsIm1vdmVCeSIsImVhc2luZyIsImVhc2VDdWJpY0FjdGlvbkluIiwiY2FsbEZ1bmMiLCJzdGFydEZydWl0UGh5c2ljcyIsInNjaGVkdWxlT25jZSIsIm5leHRJZCIsImdldE5leHRGcnVpdElkIiwicnVuQWN0aW9uIiwiaXNGYWxsaW5nIiwiZmFsbFN0YXJ0VGltZSIsIkRhdGUiLCJub3ciLCJNYXRoIiwiZmxvb3IiLCJyYW5kb20iLCJjcmVhdGVPbmVGcnVpdCIsIm51bSIsImluc3RhbnRpYXRlIiwiY29uZmlnIiwiaW5pdCIsIlBoeXNpY3NDaXJjbGVDb2xsaWRlciIsInJhZGl1cyIsImFkZENoaWxkIiwic2NhbGUiLCJvblNhbWVGcnVpdENvbnRhY3QiLCJiaW5kIiwiRHluYW1pYyIsInBoeXNpY3NDaXJjbGVDb2xsaWRlciIsImFwcGx5Iiwic2V0UG9zaXRpb24iLCJzZWxmIiwib3RoZXIiLCJvZmYiLCJyZW1vdmVGcm9tUGFyZW50IiwiY3JlYXRlRnJ1aXRKdWljZSIsImFkZFNjb3JlIiwibmV3RnJ1aXQiLCJ0d2VlbiIsInRvIiwic3RhcnQiLCJuIiwiYXVkaW9FbmdpbmUiLCJwbGF5IiwianVpY2UiLCJzaG93SnVpY2UiLCJmcnVpdElkIiwic3RyaW5nIiwiZW5kR2FtZSIsInBhdXNlQWxsQWN0aW9ucyIsImxvYWRTY2VuZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFNQSxLQUFLLEdBQUdDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ25CQyxJQUFJLEVBQUUsV0FEYTtFQUVuQkMsVUFBVSxFQUFFO0lBQ1JDLEVBQUUsRUFBRSxDQURJO0lBRVJDLE1BQU0sRUFBRUwsRUFBRSxDQUFDTTtFQUZIO0FBRk8sQ0FBVCxDQUFkO0FBUUEsSUFBTUMsU0FBUyxHQUFHUCxFQUFFLENBQUNDLEtBQUgsQ0FBUztFQUN2QkMsSUFBSSxFQUFFLFdBRGlCO0VBRXZCQyxVQUFVLEVBQUU7SUFDUkssUUFBUSxFQUFFUixFQUFFLENBQUNNLFdBREw7SUFFUkcsTUFBTSxFQUFFVCxFQUFFLENBQUNNLFdBRkg7SUFHUkksS0FBSyxFQUFFVixFQUFFLENBQUNNO0VBSEY7QUFGVyxDQUFULENBQWxCO0FBU0EsSUFBTUssVUFBVSxHQUFHLENBQUMsR0FBcEI7QUFFQVgsRUFBRSxDQUFDQyxLQUFILENBQVM7RUFDTCxXQUFTRCxFQUFFLENBQUNZLFNBRFA7RUFHTFQsVUFBVSxFQUFFO0lBQ1JVLE1BQU0sRUFBRTtNQUNKLFdBQVMsRUFETDtNQUVKQyxJQUFJLEVBQUVmO0lBRkYsQ0FEQTtJQU1SZ0IsTUFBTSxFQUFFO01BQ0osV0FBUyxFQURMO01BRUpELElBQUksRUFBRVA7SUFGRixDQU5BO0lBV1JTLFdBQVcsRUFBRTtNQUNULFdBQVMsSUFEQTtNQUVURixJQUFJLEVBQUVkLEVBQUUsQ0FBQ2lCO0lBRkEsQ0FYTDtJQWdCUkMsV0FBVyxFQUFFO01BQ1QsV0FBUyxJQURBO01BRVRKLElBQUksRUFBRWQsRUFBRSxDQUFDaUI7SUFGQSxDQWhCTDtJQXFCUkUsU0FBUyxFQUFFO01BQ1AsV0FBUyxJQURGO01BRVBMLElBQUksRUFBRWQsRUFBRSxDQUFDb0I7SUFGRixDQXJCSDtJQXlCUkMsVUFBVSxFQUFFO01BQ1IsV0FBUyxJQUREO01BRVJQLElBQUksRUFBRWQsRUFBRSxDQUFDb0I7SUFGRCxDQXpCSjtJQTZCUkUsVUFBVSxFQUFFO01BQ1IsV0FBUyxJQUREO01BRVJSLElBQUksRUFBRWQsRUFBRSxDQUFDb0I7SUFGRCxDQTdCSjtJQWlDUkcsVUFBVSxFQUFFO01BQ1IsV0FBUyxJQUREO01BRVJULElBQUksRUFBRWQsRUFBRSxDQUFDd0I7SUFGRCxDQWpDSjtJQXNDUkMsU0FBUyxFQUFDekIsRUFBRSxDQUFDMEIsSUF0Q0w7SUF1Q1JDLGNBQWMsRUFBRSxDQXZDUixDQXVDVzs7RUF2Q1gsQ0FIUDtFQTZDTEMsTUE3Q0ssb0JBNkNJO0lBQ0wsS0FBS0MsV0FBTDtJQUVBN0IsRUFBRSxDQUFDOEIsUUFBSCxDQUFZQyxtQkFBWixHQUFrQ0MsT0FBbEMsR0FBNEMsSUFBNUM7SUFFQSxLQUFLQyxVQUFMLEdBQWtCLEtBQWxCO0lBQ0EsS0FBS0MsVUFBTCxHQUFrQixDQUFsQjtJQUNBLEtBQUtDLEtBQUwsR0FBYSxDQUFiO0lBRUEsS0FBS0MsSUFBTCxDQUFVQyxFQUFWLENBQWFyQyxFQUFFLENBQUMwQixJQUFILENBQVFZLFNBQVIsQ0FBa0JDLFVBQS9CLEVBQTJDLEtBQUtDLFlBQWhELEVBQThELElBQTlELEVBVEssQ0FVTDs7SUFDQSxLQUFLSixJQUFMLENBQVVDLEVBQVYsQ0FBYXJDLEVBQUUsQ0FBQzBCLElBQUgsQ0FBUVksU0FBUixDQUFrQkcsUUFBL0IsRUFBeUMsS0FBS0MsVUFBOUMsRUFBMEQsSUFBMUQsRUFYSyxDQWFMO0lBQ0E7SUFDQTtJQUVBOztJQUVBLEtBQUtDLFlBQUw7SUFFQSxJQUFJQyxRQUFRLEdBQUcsS0FBS1IsSUFBTCxDQUFVUyxZQUFWLENBQXVCN0MsRUFBRSxDQUFDOEMsUUFBMUIsQ0FBZjs7SUFDQSxJQUFJRixRQUFKLEVBQWM7TUFDVkEsUUFBUSxDQUFDUCxFQUFULENBQVlyQyxFQUFFLENBQUMrQyxhQUFILENBQWlCQyxhQUE3QixFQUE0QyxLQUFLQyxjQUFqRCxFQUFpRSxJQUFqRTtNQUNBTCxRQUFRLENBQUNQLEVBQVQsQ0FBWXJDLEVBQUUsQ0FBQytDLGFBQUgsQ0FBaUJHLFdBQTdCLEVBQTBDLEtBQUtDLFlBQS9DLEVBQTZELElBQTdEO0lBQ0gsQ0F6QkksQ0EyQkw7SUFDQTtJQUNBO0lBQ0E7SUFDQTs7RUFFSCxDQTlFSTtFQWdGTDtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFFQXRCLFdBOUZLLHlCQThGUztJQUNWLElBQU11QixRQUFRLEdBQUdwRCxFQUFFLENBQUM4QixRQUFILENBQVl1QixpQkFBWixFQUFqQjtJQUNBRCxRQUFRLENBQUNwQixPQUFULEdBQW1CLElBQW5CO0lBQ0FvQixRQUFRLENBQUNFLE9BQVQsR0FBbUJ0RCxFQUFFLENBQUN1RCxFQUFILENBQU0sQ0FBTixFQUFTLENBQUMsR0FBVixDQUFuQjtJQUVBLElBQU1DLGdCQUFnQixHQUFHeEQsRUFBRSxDQUFDOEIsUUFBSCxDQUFZQyxtQkFBWixFQUF6QjtJQUNBeUIsZ0JBQWdCLENBQUN4QixPQUFqQixHQUEyQixJQUEzQjtJQUVBLElBQUl5QixLQUFLLEdBQUcsS0FBS3JCLElBQUwsQ0FBVXFCLEtBQXRCO0lBQ0EsSUFBSUMsTUFBTSxHQUFHLEtBQUt0QixJQUFMLENBQVVzQixNQUF2QjtJQUVBLElBQUl0QixJQUFJLEdBQUcsSUFBSXBDLEVBQUUsQ0FBQzBCLElBQVAsRUFBWDtJQUVBLElBQUlpQyxJQUFJLEdBQUd2QixJQUFJLENBQUN3QixZQUFMLENBQWtCNUQsRUFBRSxDQUFDNkQsU0FBckIsQ0FBWDtJQUNBRixJQUFJLENBQUM3QyxJQUFMLEdBQVlkLEVBQUUsQ0FBQzhELGFBQUgsQ0FBaUJDLE1BQTdCOztJQUVBLElBQU1DLFNBQVMsR0FBRyxTQUFaQSxTQUFZLENBQUM1QixJQUFELEVBQU82QixDQUFQLEVBQVVDLENBQVYsRUFBYVQsS0FBYixFQUFvQkMsTUFBcEIsRUFBK0I7TUFDN0MsSUFBSWQsUUFBUSxHQUFHUixJQUFJLENBQUN3QixZQUFMLENBQWtCNUQsRUFBRSxDQUFDbUUsa0JBQXJCLENBQWY7TUFDQXZCLFFBQVEsQ0FBQ3dCLE1BQVQsQ0FBZ0JILENBQWhCLEdBQW9CQSxDQUFwQjtNQUNBckIsUUFBUSxDQUFDd0IsTUFBVCxDQUFnQkYsQ0FBaEIsR0FBb0JBLENBQXBCO01BQ0F0QixRQUFRLENBQUN5QixJQUFULENBQWNaLEtBQWQsR0FBc0JBLEtBQXRCO01BQ0FiLFFBQVEsQ0FBQ3lCLElBQVQsQ0FBY1gsTUFBZCxHQUF1QkEsTUFBdkI7SUFDSCxDQU5EOztJQVFBTSxTQUFTLENBQUM1QixJQUFELEVBQU8sQ0FBUCxFQUFVLENBQUNzQixNQUFELEdBQVUsQ0FBcEIsRUFBdUJELEtBQXZCLEVBQThCLENBQTlCLENBQVQ7O0lBQ0FPLFNBQVMsQ0FBQzVCLElBQUQsRUFBTyxDQUFQLEVBQVVzQixNQUFNLEdBQUcsQ0FBbkIsRUFBc0JELEtBQXRCLEVBQTZCLENBQTdCLENBQVQ7O0lBQ0FPLFNBQVMsQ0FBQzVCLElBQUQsRUFBTyxDQUFDcUIsS0FBRCxHQUFTLENBQWhCLEVBQW1CLENBQW5CLEVBQXNCLENBQXRCLEVBQXlCQyxNQUF6QixDQUFUOztJQUNBTSxTQUFTLENBQUM1QixJQUFELEVBQU9xQixLQUFLLEdBQUcsQ0FBZixFQUFrQixDQUFsQixFQUFxQixDQUFyQixFQUF3QkMsTUFBeEIsQ0FBVDs7SUFFQXRCLElBQUksQ0FBQ2tDLE1BQUwsR0FBYyxLQUFLbEMsSUFBbkI7RUFDSCxDQTVISTtFQThITE8sWUE5SEssd0JBOEhRdkMsRUE5SFIsRUE4SGdCO0lBQUEsSUFBUkEsRUFBUTtNQUFSQSxFQUFRLEdBQUgsQ0FBRztJQUFBOztJQUNqQixLQUFLOEIsVUFBTDtJQUNBLEtBQUtxQyxZQUFMLEdBQW9CLEtBQUtDLGdCQUFMLENBQXNCLENBQXRCLEVBQXlCLEdBQXpCLEVBQThCcEUsRUFBOUIsQ0FBcEI7RUFDSCxDQWpJSTtFQW1JTG9DLFlBbklLLHdCQW1JUWlDLENBbklSLEVBbUlXO0lBQUE7O0lBQ1osSUFBSSxLQUFLeEMsVUFBVCxFQUFxQjtJQUNyQixLQUFLQSxVQUFMLEdBQWtCLElBQWxCO0lBQ0EsaUJBQXdCLEtBQUtHLElBQTdCO0lBQUEsSUFBT3FCLEtBQVAsY0FBT0EsS0FBUDtJQUFBLElBQWNDLE1BQWQsY0FBY0EsTUFBZDtJQUVBLElBQU1nQixLQUFLLEdBQUcsS0FBS0gsWUFBbkI7SUFFQSxJQUFNSSxHQUFHLEdBQUdGLENBQUMsQ0FBQ0csV0FBRixFQUFaO0lBQ0EsSUFBS1gsQ0FBTCxHQUFhVSxHQUFiLENBQUtWLENBQUw7SUFBQSxJQUFRQyxDQUFSLEdBQWFTLEdBQWIsQ0FBUVQsQ0FBUjtJQUNBRCxDQUFDLEdBQUcsQ0FBQ0EsQ0FBQyxHQUFHUixLQUFLLEdBQUcsQ0FBYixJQUFnQixHQUFwQjtJQUNBUyxDQUFDLEdBQUcsQ0FBQ0EsQ0FBQyxHQUFHUixNQUFNLEdBQUcsQ0FBZCxJQUFpQixHQUFyQjtJQUVBLElBQU1tQixNQUFNLEdBQUc3RSxFQUFFLENBQUM4RSxRQUFILENBQVk5RSxFQUFFLENBQUMrRSxNQUFILENBQVUsR0FBVixFQUFlL0UsRUFBRSxDQUFDdUQsRUFBSCxDQUFNVSxDQUFOLEVBQVMsQ0FBVCxDQUFmLEVBQTRCZSxNQUE1QixDQUFtQ2hGLEVBQUUsQ0FBQ2lGLGlCQUFILEVBQW5DLENBQVosRUFBd0VqRixFQUFFLENBQUNrRixRQUFILENBQVksWUFBTTtNQUNyRyxLQUFJLENBQUNDLGlCQUFMLENBQXVCVCxLQUF2Qjs7TUFFQSxLQUFJLENBQUNVLFlBQUwsQ0FBa0IsWUFBTTtRQUNwQixJQUFNQyxNQUFNLEdBQUcsS0FBSSxDQUFDQyxjQUFMLEVBQWY7O1FBQ0EsS0FBSSxDQUFDM0MsWUFBTCxDQUFrQjBDLE1BQWxCOztRQUNBLEtBQUksQ0FBQ3BELFVBQUwsR0FBa0IsS0FBbEI7TUFDSCxDQUpELEVBSUcsQ0FKSDtJQUtILENBUnNGLENBQXhFLENBQWY7SUFVQXlDLEtBQUssQ0FBQ2EsU0FBTixDQUFnQlYsTUFBaEI7RUFDSCxDQTFKSTtFQTRKTG5DLFVBNUpLLHNCQTRKTStCLENBNUpOLEVBNEpTO0lBQUE7O0lBQ1YsS0FBS1csWUFBTCxDQUFrQixZQUFNO01BQ3BCLElBQUksTUFBSSxDQUFDYixZQUFULEVBQXVCO1FBQ25CO1FBQ0EsTUFBSSxDQUFDQSxZQUFMLENBQWtCMUIsWUFBbEIsQ0FBK0IsT0FBL0IsRUFBd0MyQyxTQUF4QyxHQUFvRCxJQUFwRDtRQUNBLE1BQUksQ0FBQ2pCLFlBQUwsQ0FBa0IxQixZQUFsQixDQUErQixPQUEvQixFQUF3QzRDLGFBQXhDLEdBQXdEQyxJQUFJLENBQUNDLEdBQUwsRUFBeEQsQ0FIbUIsQ0FHaUQ7TUFDdkU7SUFDSixDQU5ELEVBTUcsR0FOSCxFQURVLENBT0Q7RUFDWixDQXBLSTtFQXNLTEwsY0F0S0ssNEJBc0tZO0lBQ2IsSUFBSSxLQUFLcEQsVUFBTCxHQUFrQixDQUF0QixFQUF5QjtNQUNyQixPQUFPLENBQVA7SUFDSCxDQUZELE1BRU8sSUFBSSxLQUFLQSxVQUFMLEtBQW9CLENBQXhCLEVBQTJCO01BQzlCLE9BQU8sQ0FBUDtJQUNILENBRk0sTUFFQTtNQUNIO01BQ0EsT0FBTzBELElBQUksQ0FBQ0MsS0FBTCxDQUFXRCxJQUFJLENBQUNFLE1BQUwsS0FBZ0IsQ0FBM0IsSUFBZ0MsQ0FBdkM7SUFDSDtFQUNKLENBL0tJO0VBaUxMQyxjQWpMSywwQkFpTFVDLEdBakxWLEVBaUxlO0lBQ2hCLElBQUl0QixLQUFLLEdBQUcxRSxFQUFFLENBQUNpRyxXQUFILENBQWUsS0FBS2pGLFdBQXBCLENBQVo7SUFDQSxJQUFNa0YsTUFBTSxHQUFHLEtBQUtyRixNQUFMLENBQVltRixHQUFHLEdBQUcsQ0FBbEIsQ0FBZjtJQUVBdEIsS0FBSyxDQUFDN0IsWUFBTixDQUFtQixPQUFuQixFQUE0QnNELElBQTVCLENBQWlDO01BQzdCL0YsRUFBRSxFQUFFOEYsTUFBTSxDQUFDOUYsRUFEa0I7TUFFN0JDLE1BQU0sRUFBRTZGLE1BQU0sQ0FBQzdGO0lBRmMsQ0FBakM7SUFLQXFFLEtBQUssQ0FBQzdCLFlBQU4sQ0FBbUI3QyxFQUFFLENBQUM2RCxTQUF0QixFQUFpQy9DLElBQWpDLEdBQXdDZCxFQUFFLENBQUM4RCxhQUFILENBQWlCQyxNQUF6RDtJQUNBVyxLQUFLLENBQUM3QixZQUFOLENBQW1CN0MsRUFBRSxDQUFDb0cscUJBQXRCLEVBQTZDQyxNQUE3QyxHQUFzRCxDQUF0RDtJQUVBLEtBQUtqRSxJQUFMLENBQVVrRSxRQUFWLENBQW1CNUIsS0FBbkI7SUFDQUEsS0FBSyxDQUFDNkIsS0FBTixHQUFjLEdBQWQ7SUFFQTdCLEtBQUssQ0FBQ3JDLEVBQU4sQ0FBUyxhQUFULEVBQXdCLEtBQUttRSxrQkFBTCxDQUF3QkMsSUFBeEIsQ0FBNkIsSUFBN0IsQ0FBeEI7SUFFQSxPQUFPL0IsS0FBUDtFQUNILENBbk1JO0VBb01MUyxpQkFwTUssNkJBb01hVCxLQXBNYixFQW9Nb0I7SUFDckJBLEtBQUssQ0FBQzdCLFlBQU4sQ0FBbUI3QyxFQUFFLENBQUM2RCxTQUF0QixFQUFpQy9DLElBQWpDLEdBQXdDZCxFQUFFLENBQUM4RCxhQUFILENBQWlCNEMsT0FBekQ7SUFDQSxJQUFNQyxxQkFBcUIsR0FBR2pDLEtBQUssQ0FBQzdCLFlBQU4sQ0FBbUI3QyxFQUFFLENBQUNvRyxxQkFBdEIsQ0FBOUI7SUFDQU8scUJBQXFCLENBQUNOLE1BQXRCLEdBQStCM0IsS0FBSyxDQUFDaEIsTUFBTixHQUFlLENBQTlDO0lBQ0FpRCxxQkFBcUIsQ0FBQ0MsS0FBdEI7RUFDSCxDQXpNSTtFQTJNTDtFQUNBcEMsZ0JBNU1LLDRCQTRNWVAsQ0E1TVosRUE0TWVDLENBNU1mLEVBNE1rQnBELElBNU1sQixFQTRNNEI7SUFBQSxJQUFWQSxJQUFVO01BQVZBLElBQVUsR0FBSCxDQUFHO0lBQUE7O0lBQzdCLElBQU00RCxLQUFLLEdBQUcsS0FBS3FCLGNBQUwsQ0FBb0JqRixJQUFwQixDQUFkO0lBQ0E0RCxLQUFLLENBQUNtQyxXQUFOLENBQWtCN0csRUFBRSxDQUFDdUQsRUFBSCxDQUFNVSxDQUFOLEVBQVNDLENBQVQsQ0FBbEI7SUFDQSxPQUFPUSxLQUFQO0VBQ0gsQ0FoTkk7RUFpTkw7RUFDQThCLGtCQWxOSyxvQ0FrTjZCO0lBQUEsSUFBZE0sSUFBYyxRQUFkQSxJQUFjO0lBQUEsSUFBUkMsS0FBUSxRQUFSQSxLQUFRO0lBQzlCQSxLQUFLLENBQUMzRSxJQUFOLENBQVc0RSxHQUFYLENBQWUsYUFBZixFQUQ4QixDQUNBOztJQUU5QixJQUFNNUcsRUFBRSxHQUFHMkcsS0FBSyxDQUFDbEUsWUFBTixDQUFtQixPQUFuQixFQUE0QnpDLEVBQXZDLENBSDhCLENBSTlCOztJQUNBMEcsSUFBSSxDQUFDMUUsSUFBTCxDQUFVNkUsZ0JBQVYsQ0FBMkIsSUFBM0I7SUFDQUYsS0FBSyxDQUFDM0UsSUFBTixDQUFXNkUsZ0JBQVgsQ0FBNEIsSUFBNUI7SUFFQSxrQkFBZUYsS0FBSyxDQUFDM0UsSUFBckI7SUFBQSxJQUFPNkIsQ0FBUCxlQUFPQSxDQUFQO0lBQUEsSUFBVUMsQ0FBVixlQUFVQSxDQUFWO0lBRUEsS0FBS2dELGdCQUFMLENBQXNCOUcsRUFBdEIsRUFBMEJKLEVBQUUsQ0FBQ3VELEVBQUgsQ0FBTTtNQUFDVSxDQUFDLEVBQURBLENBQUQ7TUFBSUMsQ0FBQyxFQUFEQTtJQUFKLENBQU4sQ0FBMUIsRUFBeUM2QyxLQUFLLENBQUMzRSxJQUFOLENBQVdxQixLQUFwRDtJQUVBLEtBQUswRCxRQUFMLENBQWMvRyxFQUFkO0lBRUEsSUFBTWlGLE1BQU0sR0FBR2pGLEVBQUUsR0FBRyxDQUFwQjs7SUFDQSxJQUFJaUYsTUFBTSxJQUFJLEVBQWQsRUFBa0I7TUFDZCxJQUFNK0IsUUFBUSxHQUFHLEtBQUs1QyxnQkFBTCxDQUFzQlAsQ0FBdEIsRUFBeUJDLENBQXpCLEVBQTRCbUIsTUFBNUIsQ0FBakI7TUFFQSxLQUFLRixpQkFBTCxDQUF1QmlDLFFBQXZCLEVBSGMsQ0FLZDs7TUFDQUEsUUFBUSxDQUFDYixLQUFULEdBQWlCLENBQWpCO01BQ0F2RyxFQUFFLENBQUNxSCxLQUFILENBQVNELFFBQVQsRUFBbUJFLEVBQW5CLENBQXNCLEVBQXRCLEVBQTBCO1FBQ3RCZixLQUFLLEVBQUU7TUFEZSxDQUExQixFQUVHO1FBQ0N2QixNQUFNLEVBQUU7TUFEVCxDQUZILEVBSUd1QyxLQUpIO0lBS0g7RUFDSixDQTlPSTtFQWlQTEwsZ0JBalBLLDRCQWlQWTlHLEVBalBaLEVBaVBnQnVFLEdBalBoQixFQWlQcUI2QyxDQWpQckIsRUFpUHdCO0lBQ3pCeEgsRUFBRSxDQUFDeUgsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUt2RyxTQUF6QixFQUFvQyxLQUFwQyxFQUEyQyxDQUEzQztJQUNBbkIsRUFBRSxDQUFDeUgsV0FBSCxDQUFlQyxJQUFmLENBQW9CLEtBQUtwRyxVQUF6QixFQUFxQyxLQUFyQyxFQUE0QyxDQUE1QztJQUVBLElBQUlxRyxLQUFLLEdBQUczSCxFQUFFLENBQUNpRyxXQUFILENBQWUsS0FBSy9FLFdBQXBCLENBQVo7SUFDQSxLQUFLa0IsSUFBTCxDQUFVa0UsUUFBVixDQUFtQnFCLEtBQW5CO0lBRUEsSUFBTXpCLE1BQU0sR0FBRyxLQUFLbkYsTUFBTCxDQUFZWCxFQUFFLEdBQUcsQ0FBakIsQ0FBZjtJQUNBLElBQU1nRCxRQUFRLEdBQUd1RSxLQUFLLENBQUM5RSxZQUFOLENBQW1CLE9BQW5CLENBQWpCO0lBQ0FPLFFBQVEsQ0FBQytDLElBQVQsQ0FBY0QsTUFBZDtJQUNBOUMsUUFBUSxDQUFDd0UsU0FBVCxDQUFtQmpELEdBQW5CLEVBQXdCNkMsQ0FBeEI7RUFDSCxDQTVQSTtFQTZQTEwsUUE3UEssb0JBNlBJVSxPQTdQSixFQTZQYTtJQUNkLEtBQUsxRixLQUFMLElBQWMwRixPQUFPLEdBQUcsQ0FBeEI7SUFDQSxLQUFLdEcsVUFBTCxDQUFnQnVHLE1BQWhCLEdBQXlCLEtBQUszRixLQUE5QjtFQUNILENBaFFJO0VBaVFMNEYsT0FqUUsscUJBaVFLO0lBQ04sS0FBSzNGLElBQUwsQ0FBVTRGLGVBQVYsR0FETSxDQUN1Qjs7SUFDN0JoSSxFQUFFLENBQUM4QixRQUFILENBQVltRyxTQUFaLENBQXNCLEtBQXRCLEVBRk0sQ0FHTjtFQUNIO0FBclFJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IEZydWl0ID0gY2MuQ2xhc3MoeyAgXG4gICAgbmFtZTogJ0ZydWl0SXRlbScsICBcbiAgICBwcm9wZXJ0aWVzOiB7ICBcbiAgICAgICAgaWQ6IDAsICBcbiAgICAgICAgaWNvblNGOiBjYy5TcHJpdGVGcmFtZSwgIFxuICAgIH0gIFxufSk7XG5cbmNvbnN0IEp1aWNlSXRlbSA9IGNjLkNsYXNzKHtcbiAgICBuYW1lOiAnSnVpY2VJdGVtJyxcbiAgICBwcm9wZXJ0aWVzOiB7XG4gICAgICAgIHBhcnRpY2xlOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgY2lyY2xlOiBjYy5TcHJpdGVGcmFtZSxcbiAgICAgICAgc2xhc2g6IGNjLlNwcml0ZUZyYW1lLFxuICAgIH1cbn0pO1xuXG5jb25zdCBNQVhfSEVJR0hUID0gLTMwMDtcblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgZnJ1aXRzOiB7XG4gICAgICAgICAgICBkZWZhdWx0OiBbXSxcbiAgICAgICAgICAgIHR5cGU6IEZydWl0XG4gICAgICAgIH0sXG5cbiAgICAgICAganVpY2VzOiB7XG4gICAgICAgICAgICBkZWZhdWx0OiBbXSxcbiAgICAgICAgICAgIHR5cGU6IEp1aWNlSXRlbVxuICAgICAgICB9LFxuXG4gICAgICAgIGZydWl0UHJlZmFiOiB7XG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuUHJlZmFiXG4gICAgICAgIH0sXG5cbiAgICAgICAganVpY2VQcmVmYWI6IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5QcmVmYWJcbiAgICAgICAgfSxcblxuICAgICAgICBib29tQXVkaW86IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5BdWRpb0NsaXBcbiAgICAgICAgfSxcbiAgICAgICAga25vY2tBdWRpbzoge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLkF1ZGlvQ2xpcFxuICAgICAgICB9LFxuICAgICAgICB3YXRlckF1ZGlvOiB7XG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxuICAgICAgICAgICAgdHlwZTogY2MuQXVkaW9DbGlwXG4gICAgICAgIH0sXG4gICAgICAgIHNjb3JlTGFiZWw6IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5MYWJlbFxuICAgICAgICB9LFxuXG4gICAgICAgIGRlYWRfbGluZTpjYy5Ob2RlLFxuICAgICAgICBjb2xsaXNpb25Db3VudDogMCwgLy8g5re75Yqg56Kw5pKe6K6h5pWw5ZmoICBcbiAgICB9LFxuICAgXG4gICAgb25Mb2FkKCkgeyAgXG4gICAgICAgIHRoaXMuaW5pdFBoeXNpY3MoKTsgIFxuXG4gICAgICAgIGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKS5lbmFibGVkID0gdHJ1ZTsgIFxuXG4gICAgICAgIHRoaXMuaXNDcmVhdGluZyA9IGZhbHNlOyAgXG4gICAgICAgIHRoaXMuZnJ1aXRDb3VudCA9IDA7ICBcbiAgICAgICAgdGhpcy5zY29yZSA9IDA7ICBcblxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfRE9XTiwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpOyAgXG4gICAgICAgIC8vIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5NT1VTRV9NT1ZFLCB0aGlzLm9uVG91Y2hNb3ZlLCB0aGlzKTsgIFxuICAgICAgICB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuTU9VU0VfVVAsIHRoaXMub25Ub3VjaEVuZCwgdGhpcyk7ICBcbiAgICAgICAgXG4gICAgICAgIC8vIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpOyAgXG4gICAgICAgIC8vIHRoaXMubm9kZS5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCB0aGlzLm9uVG91Y2hNb3ZlLCB0aGlzKTsgIFxuICAgICAgICAvLyB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCB0aGlzLm9uVG91Y2hFbmQsIHRoaXMpOyAgXG4gICAgICAgIFxuICAgICAgICAvLyB0aGlzLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfQ0FOQ0VMLCB0aGlzLm9uVG91Y2hDYW5jZWwsIHRoaXMpOyAgXG4gICAgICAgIFxuICAgICAgICB0aGlzLmluaXRPbmVGcnVpdCgpO1xuICAgICAgICBcbiAgICAgICAgbGV0IGNvbGxpZGVyID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5Db2xsaWRlcik7ICBcbiAgICAgICAgaWYgKGNvbGxpZGVyKSB7ICBcbiAgICAgICAgICAgIGNvbGxpZGVyLm9uKGNjLkNvbnRhY3QyRFR5cGUuQkVHSU5fQ09OVEFDVCwgdGhpcy5vbkJlZ2luQ29udGFjdCwgdGhpcyk7ICBcbiAgICAgICAgICAgIGNvbGxpZGVyLm9uKGNjLkNvbnRhY3QyRFR5cGUuRU5EX0NPTlRBQ1QsIHRoaXMub25FbmRDb250YWN0LCB0aGlzKTsgIFxuICAgICAgICB9ICBcblxuICAgICAgICAvLyDms6jlhozlhajlsYDnorDmkp7lm57osIPlh73mlbAgIFxuICAgICAgICAvLyBpZiAoY2MuUGh5c2ljc1N5c3RlbTJELmluc3RhbmNlKSB7ICBcbiAgICAgICAgLy8gICAgIGNjLlBoeXNpY3NTeXN0ZW0yRC5pbnN0YW5jZS5vbihjYy5Db250YWN0MkRUeXBlLkJFR0lOX0NPTlRBQ1QsIHRoaXMub25CZWdpbkNvbnRhY3QsIHRoaXMpOyAgXG4gICAgICAgIC8vICAgICBjYy5QaHlzaWNzU3lzdGVtMkQuaW5zdGFuY2Uub24oY2MuQ29udGFjdDJEVHlwZS5FTkRfQ09OVEFDVCwgdGhpcy5vbkVuZENvbnRhY3QsIHRoaXMpOyAgXG4gICAgICAgIC8vIH0gIFxuXG4gICAgfSwgICBcbiBcbiAgICAvLyBvbkNvbGxpc2lvbkVudGVyKG90aGVyLHNlbGYsY29udGFjdCkgeyAgXG4gICAgLy8gICAgIGNvbnNvbGUubG9nKFwi6Kem5Y+R5qOA5rWL5ZCv5YqoXCIpOyAgXG4gICAgLy8gICAgIGNvbnNvbGUubG9nKFwi56Kw5pKe5qOA5rWLOiBcIiwgb3RoZXIubm9kZS5uYW1lKTsgIFxuICAgIC8vICAgICBpZiAob3RoZXIubm9kZS5uYW1lID09PSBcIkRlYWRfbGluZVwiKSB7ICBcbiAgICAvLyAgICAgICAgIGNvbnN0IGdhbWVDb250cm9sbGVyID0gY2MuZmluZCgnR2FtZUNvbnRyb2xsZXInKS5nZXRDb21wb25lbnQoJ+S9oOeahOa4uOaIj+aOp+WItuiEmuacrCcpOyAgXG4gICAgLy8gICAgICAgICBnYW1lQ29udHJvbGxlci5jb2xsaXNpb25Db3VudCsrOyAgIFxuICAgIFxuICAgIC8vICAgICAgICAgY29uc29sZS5sb2coXCLnorDmkp7mrKHmlbA6IFwiICsgZ2FtZUNvbnRyb2xsZXIuY29sbGlzaW9uQ291bnQpOyAgXG4gICAgLy8gICAgICAgICBpZiAoZ2FtZUNvbnRyb2xsZXIuY29sbGlzaW9uQ291bnQgPj0gMikgeyAgXG4gICAgLy8gICAgICAgICAgICAgZ2FtZUNvbnRyb2xsZXIuZW5kR2FtZSgpOyAgIFxuICAgIC8vICAgICAgICAgfSAgXG4gICAgLy8gICAgIH0gIFxuICAgIC8vIH0sXG4gICAgXG4gICAgaW5pdFBoeXNpY3MoKSB7XG4gICAgICAgIGNvbnN0IGluc3RhbmNlID0gY2MuZGlyZWN0b3IuZ2V0UGh5c2ljc01hbmFnZXIoKVxuICAgICAgICBpbnN0YW5jZS5lbmFibGVkID0gdHJ1ZVxuICAgICAgICBpbnN0YW5jZS5ncmF2aXR5ID0gY2MudjIoMCwgLTMwMCk7XG5cbiAgICAgICAgY29uc3QgY29sbGlzaW9uTWFuYWdlciA9IGNjLmRpcmVjdG9yLmdldENvbGxpc2lvbk1hbmFnZXIoKTtcbiAgICAgICAgY29sbGlzaW9uTWFuYWdlci5lbmFibGVkID0gdHJ1ZVxuXG4gICAgICAgIGxldCB3aWR0aCA9IHRoaXMubm9kZS53aWR0aDtcbiAgICAgICAgbGV0IGhlaWdodCA9IHRoaXMubm9kZS5oZWlnaHQ7XG5cbiAgICAgICAgbGV0IG5vZGUgPSBuZXcgY2MuTm9kZSgpO1xuXG4gICAgICAgIGxldCBib2R5ID0gbm9kZS5hZGRDb21wb25lbnQoY2MuUmlnaWRCb2R5KTtcbiAgICAgICAgYm9keS50eXBlID0gY2MuUmlnaWRCb2R5VHlwZS5TdGF0aWM7XG5cbiAgICAgICAgY29uc3QgX2FkZEJvdW5kID0gKG5vZGUsIHgsIHksIHdpZHRoLCBoZWlnaHQpID0+IHtcbiAgICAgICAgICAgIGxldCBjb2xsaWRlciA9IG5vZGUuYWRkQ29tcG9uZW50KGNjLlBoeXNpY3NCb3hDb2xsaWRlcik7XG4gICAgICAgICAgICBjb2xsaWRlci5vZmZzZXQueCA9IHg7XG4gICAgICAgICAgICBjb2xsaWRlci5vZmZzZXQueSA9IHk7XG4gICAgICAgICAgICBjb2xsaWRlci5zaXplLndpZHRoID0gd2lkdGg7XG4gICAgICAgICAgICBjb2xsaWRlci5zaXplLmhlaWdodCA9IGhlaWdodDtcbiAgICAgICAgfVxuXG4gICAgICAgIF9hZGRCb3VuZChub2RlLCAwLCAtaGVpZ2h0IC8gMiwgd2lkdGgsIDEpO1xuICAgICAgICBfYWRkQm91bmQobm9kZSwgMCwgaGVpZ2h0IC8gMiwgd2lkdGgsIDEpO1xuICAgICAgICBfYWRkQm91bmQobm9kZSwgLXdpZHRoIC8gMiwgMCwgMSwgaGVpZ2h0KTtcbiAgICAgICAgX2FkZEJvdW5kKG5vZGUsIHdpZHRoIC8gMiwgMCwgMSwgaGVpZ2h0KTtcblxuICAgICAgICBub2RlLnBhcmVudCA9IHRoaXMubm9kZTtcbiAgICB9LFxuXG4gICAgaW5pdE9uZUZydWl0KGlkID0gMSkge1xuICAgICAgICB0aGlzLmZydWl0Q291bnQrK1xuICAgICAgICB0aGlzLmN1cnJlbnRGcnVpdCA9IHRoaXMuY3JlYXRlRnJ1aXRPblBvcygwLCAzNDAsIGlkKVxuICAgIH0sXG5cbiAgICBvblRvdWNoU3RhcnQoZSkge1xuICAgICAgICBpZiAodGhpcy5pc0NyZWF0aW5nKSByZXR1cm5cbiAgICAgICAgdGhpcy5pc0NyZWF0aW5nID0gdHJ1ZVxuICAgICAgICBjb25zdCB7d2lkdGgsIGhlaWdodH0gPSB0aGlzLm5vZGVcblxuICAgICAgICBjb25zdCBmcnVpdCA9IHRoaXMuY3VycmVudEZydWl0XG5cbiAgICAgICAgY29uc3QgcG9zID0gZS5nZXRMb2NhdGlvbigpXG4gICAgICAgIGxldCB7eCwgeX0gPSBwb3NcbiAgICAgICAgeCA9ICh4IC0gd2lkdGggLyAyKSoxLjVcbiAgICAgICAgeSA9ICh5IC0gaGVpZ2h0IC8gMikqMS41XG5cbiAgICAgICAgY29uc3QgYWN0aW9uID0gY2Muc2VxdWVuY2UoY2MubW92ZUJ5KDAuMywgY2MudjIoeCwgMCkpLmVhc2luZyhjYy5lYXNlQ3ViaWNBY3Rpb25JbigpKSwgY2MuY2FsbEZ1bmMoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5zdGFydEZydWl0UGh5c2ljcyhmcnVpdClcblxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5leHRJZCA9IHRoaXMuZ2V0TmV4dEZydWl0SWQoKVxuICAgICAgICAgICAgICAgIHRoaXMuaW5pdE9uZUZydWl0KG5leHRJZClcbiAgICAgICAgICAgICAgICB0aGlzLmlzQ3JlYXRpbmcgPSBmYWxzZVxuICAgICAgICAgICAgfSwgMSlcbiAgICAgICAgfSkpXG5cbiAgICAgICAgZnJ1aXQucnVuQWN0aW9uKGFjdGlvbilcbiAgICB9LFxuXG4gICAgb25Ub3VjaEVuZChlKSB7ICBcbiAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UoKCkgPT4geyAgXG4gICAgICAgICAgICBpZiAodGhpcy5jdXJyZW50RnJ1aXQpIHsgIFxuICAgICAgICAgICAgICAgIC8vIOiuvue9ruW9k+WJjeawtOaenOS4uuato+WcqOS4i+iQveeKtuaAgSAgXG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50RnJ1aXQuZ2V0Q29tcG9uZW50KCdGcnVpdCcpLmlzRmFsbGluZyA9IHRydWU7ICBcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRGcnVpdC5nZXRDb21wb25lbnQoJ0ZydWl0JykuZmFsbFN0YXJ0VGltZSA9IERhdGUubm93KCk7IC8vIOiusOW9leW8gOWni+S4i+iQveeahOaXtumXtCAgXG4gICAgICAgICAgICB9ICBcbiAgICAgICAgfSwgMC44KTsgLy8g5ZyoIDAuOCDnp5LlkI7orr7nva7kuIvokL3nirbmgIEgIFxuICAgIH0sXG5cbiAgICBnZXROZXh0RnJ1aXRJZCgpIHtcbiAgICAgICAgaWYgKHRoaXMuZnJ1aXRDb3VudCA8IDMpIHtcbiAgICAgICAgICAgIHJldHVybiAxXG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5mcnVpdENvdW50ID09PSAzKSB7XG4gICAgICAgICAgICByZXR1cm4gMlxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8g6ZqP5py66L+U5Zue5YmNNeS4qlxuICAgICAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIDUpICsgMVxuICAgICAgICB9XG4gICAgfSxcblxuICAgIGNyZWF0ZU9uZUZydWl0KG51bSkge1xuICAgICAgICBsZXQgZnJ1aXQgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmZydWl0UHJlZmFiKTtcbiAgICAgICAgY29uc3QgY29uZmlnID0gdGhpcy5mcnVpdHNbbnVtIC0gMV1cblxuICAgICAgICBmcnVpdC5nZXRDb21wb25lbnQoJ0ZydWl0JykuaW5pdCh7XG4gICAgICAgICAgICBpZDogY29uZmlnLmlkLFxuICAgICAgICAgICAgaWNvblNGOiBjb25maWcuaWNvblNGXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGZydWl0LmdldENvbXBvbmVudChjYy5SaWdpZEJvZHkpLnR5cGUgPSBjYy5SaWdpZEJvZHlUeXBlLlN0YXRpY1xuICAgICAgICBmcnVpdC5nZXRDb21wb25lbnQoY2MuUGh5c2ljc0NpcmNsZUNvbGxpZGVyKS5yYWRpdXMgPSAwXG5cbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKGZydWl0KTtcbiAgICAgICAgZnJ1aXQuc2NhbGUgPSAwLjZcblxuICAgICAgICBmcnVpdC5vbignc2FtZUNvbnRhY3QnLCB0aGlzLm9uU2FtZUZydWl0Q29udGFjdC5iaW5kKHRoaXMpKVxuXG4gICAgICAgIHJldHVybiBmcnVpdFxuICAgIH0sXG4gICAgc3RhcnRGcnVpdFBoeXNpY3MoZnJ1aXQpIHtcbiAgICAgICAgZnJ1aXQuZ2V0Q29tcG9uZW50KGNjLlJpZ2lkQm9keSkudHlwZSA9IGNjLlJpZ2lkQm9keVR5cGUuRHluYW1pY1xuICAgICAgICBjb25zdCBwaHlzaWNzQ2lyY2xlQ29sbGlkZXIgPSBmcnVpdC5nZXRDb21wb25lbnQoY2MuUGh5c2ljc0NpcmNsZUNvbGxpZGVyKVxuICAgICAgICBwaHlzaWNzQ2lyY2xlQ29sbGlkZXIucmFkaXVzID0gZnJ1aXQuaGVpZ2h0IC8gMlxuICAgICAgICBwaHlzaWNzQ2lyY2xlQ29sbGlkZXIuYXBwbHkoKVxuICAgIH0sXG5cbiAgICAvLyDlnKjmjIflrprkvY3nva7nlJ/miJDmsLTmnpxcbiAgICBjcmVhdGVGcnVpdE9uUG9zKHgsIHksIHR5cGUgPSAxKSB7XG4gICAgICAgIGNvbnN0IGZydWl0ID0gdGhpcy5jcmVhdGVPbmVGcnVpdCh0eXBlKVxuICAgICAgICBmcnVpdC5zZXRQb3NpdGlvbihjYy52Mih4LCB5KSk7XG4gICAgICAgIHJldHVybiBmcnVpdFxuICAgIH0sXG4gICAgLy8g5Lik5Liq5rC05p6c56Kw5pKeXG4gICAgb25TYW1lRnJ1aXRDb250YWN0KHtzZWxmLCBvdGhlcn0pIHtcbiAgICAgICAgb3RoZXIubm9kZS5vZmYoJ3NhbWVDb250YWN0JykgLy8g5Lik5Liqbm9kZemDveS8muinpuWPke+8jHRvZG8g55yL55yL5pyJ5rKh5pyJ5YW25LuW5pa55rOV5Y+q5bGV56S65LiA5qyh55qEXG5cbiAgICAgICAgY29uc3QgaWQgPSBvdGhlci5nZXRDb21wb25lbnQoJ0ZydWl0JykuaWRcbiAgICAgICAgLy8gdG9kbyDlj6/ku6Xkvb/nlKjlr7nosaHmsaDlm57mlLZcbiAgICAgICAgc2VsZi5ub2RlLnJlbW92ZUZyb21QYXJlbnQodHJ1ZSlcbiAgICAgICAgb3RoZXIubm9kZS5yZW1vdmVGcm9tUGFyZW50KHRydWUpXG5cbiAgICAgICAgY29uc3Qge3gsIHl9ID0gb3RoZXIubm9kZVxuXG4gICAgICAgIHRoaXMuY3JlYXRlRnJ1aXRKdWljZShpZCwgY2MudjIoe3gsIHl9KSwgb3RoZXIubm9kZS53aWR0aClcblxuICAgICAgICB0aGlzLmFkZFNjb3JlKGlkKVxuXG4gICAgICAgIGNvbnN0IG5leHRJZCA9IGlkICsgMVxuICAgICAgICBpZiAobmV4dElkIDw9IDExKSB7XG4gICAgICAgICAgICBjb25zdCBuZXdGcnVpdCA9IHRoaXMuY3JlYXRlRnJ1aXRPblBvcyh4LCB5LCBuZXh0SWQpXG5cbiAgICAgICAgICAgIHRoaXMuc3RhcnRGcnVpdFBoeXNpY3MobmV3RnJ1aXQpXG5cbiAgICAgICAgICAgIC8vIOWxleekuuWKqOeUuyB0b2RvIOWKqOeUu+aViOaenOmcgOimgeiwg+aVtFxuICAgICAgICAgICAgbmV3RnJ1aXQuc2NhbGUgPSAwXG4gICAgICAgICAgICBjYy50d2VlbihuZXdGcnVpdCkudG8oLjUsIHtcbiAgICAgICAgICAgICAgICBzY2FsZTogMC42XG4gICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgZWFzaW5nOiBcImJhY2tPdXRcIlxuICAgICAgICAgICAgfSkuc3RhcnQoKVxuICAgICAgICB9XG4gICAgfSxcblxuXG4gICAgY3JlYXRlRnJ1aXRKdWljZShpZCwgcG9zLCBuKSB7XG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXkodGhpcy5ib29tQXVkaW8sIGZhbHNlLCAxKTtcbiAgICAgICAgY2MuYXVkaW9FbmdpbmUucGxheSh0aGlzLndhdGVyQXVkaW8sIGZhbHNlLCAxKTtcblxuICAgICAgICBsZXQganVpY2UgPSBjYy5pbnN0YW50aWF0ZSh0aGlzLmp1aWNlUHJlZmFiKTtcbiAgICAgICAgdGhpcy5ub2RlLmFkZENoaWxkKGp1aWNlKTtcblxuICAgICAgICBjb25zdCBjb25maWcgPSB0aGlzLmp1aWNlc1tpZCAtIDFdXG4gICAgICAgIGNvbnN0IGluc3RhbmNlID0ganVpY2UuZ2V0Q29tcG9uZW50KCdKdWljZScpXG4gICAgICAgIGluc3RhbmNlLmluaXQoY29uZmlnKVxuICAgICAgICBpbnN0YW5jZS5zaG93SnVpY2UocG9zLCBuKVxuICAgIH0sXG4gICAgYWRkU2NvcmUoZnJ1aXRJZCkge1xuICAgICAgICB0aGlzLnNjb3JlICs9IGZydWl0SWQgKiAyXG4gICAgICAgIHRoaXMuc2NvcmVMYWJlbC5zdHJpbmcgPSB0aGlzLnNjb3JlXG4gICAgfSxcbiAgICBlbmRHYW1lKCkgeyAgXG4gICAgICAgIHRoaXMubm9kZS5wYXVzZUFsbEFjdGlvbnMoKTsgLy8g5pqC5YGc5b2T5YmN6IqC54K555qE5omA5pyJ5Yqo5L2cICBcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKCdlbmQnKTtcbiAgICAgICAgLy8g5L2g5Y+v5Lul5Zyo6L+Z6YeM5re75Yqg5Luj56CB5p2l5pi+56S65ri45oiP57uT5p2f55WM6Z2i5oiW5YGa5YW25LuW5aSE55CGICBcbiAgICB9XG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Juice.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '56c1eHSOMxI0L+m6MX8FMXw', 'Juice');
// scripts/Juice.js

"use strict";

var RandomInteger = function RandomInteger(e, t) {
  return Math.floor(Math.random() * (t - e) + e);
};

cc.Class({
  "extends": cc.Component,
  properties: {
    particle: {
      "default": null,
      type: cc.SpriteFrame
    },
    circle: {
      "default": null,
      type: cc.SpriteFrame
    },
    slash: {
      "default": null,
      type: cc.SpriteFrame
    }
  },
  init: function init(data) {
    this.particle = data.particle;
    this.circle = data.particle;
    this.slash = data.slash;
  },
  // 合并时的动画效果
  showJuice: function showJuice(pos, width) {
    var _this = this;

    var _loop = function _loop(i) {
      var node = new cc.Node('Sprite');
      var sp = node.addComponent(cc.Sprite);
      sp.spriteFrame = _this.particle;
      node.parent = _this.node;
      var a = 359 * Math.random(),
          i = 30 * Math.random() + width / 2,
          l = cc.v2(Math.sin(a * Math.PI / 180) * i, Math.cos(a * Math.PI / 180) * i);
      node.scale = .5 * Math.random() + width / 100;
      var p = .5 * Math.random();
      node.position = pos;
      node.runAction(cc.sequence(cc.spawn(cc.moveBy(p, l), cc.scaleTo(p + .5, .3), cc.rotateBy(p + .5, RandomInteger(-360, 360))), cc.fadeOut(.1), cc.callFunc(function () {
        node.active = false;
      }, _this)));
    };

    // 果粒
    for (var i = 0; i < 10; ++i) {
      _loop(i);
    } // 水珠


    var _loop2 = function _loop2(f) {
      var node = new cc.Node('Sprite');
      var sp = node.addComponent(cc.Sprite);
      sp.spriteFrame = _this.circle;
      node.parent = _this.node;
      var a = 359 * Math.random(),
          i = 30 * Math.random() + width / 2,
          l = cc.v2(Math.sin(a * Math.PI / 180) * i, Math.cos(a * Math.PI / 180) * i);
      node.scale = .5 * Math.random() + width / 100;
      var p = .5 * Math.random();
      node.position = pos;
      node.runAction(cc.sequence(cc.spawn(cc.moveBy(p, l), cc.scaleTo(p + .5, .3)), cc.fadeOut(.1), cc.callFunc(function () {
        node.active = false;
      }, _this)));
    };

    for (var f = 0; f < 20; f++) {
      _loop2(f);
    } // 果汁


    var node = new cc.Node('Sprite');
    var sp = node.addComponent(cc.Sprite);
    sp.spriteFrame = this.slash;
    node.parent = this.node;
    node.position = pos;
    node.scale = 0;
    node.angle = RandomInteger(0, 360);
    node.runAction(cc.sequence(cc.spawn(cc.scaleTo(.2, width / 150), cc.fadeOut(1)), cc.callFunc(function () {
      node.active = false;
    })));
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcSnVpY2UuanMiXSwibmFtZXMiOlsiUmFuZG9tSW50ZWdlciIsImUiLCJ0IiwiTWF0aCIsImZsb29yIiwicmFuZG9tIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwYXJ0aWNsZSIsInR5cGUiLCJTcHJpdGVGcmFtZSIsImNpcmNsZSIsInNsYXNoIiwiaW5pdCIsImRhdGEiLCJzaG93SnVpY2UiLCJwb3MiLCJ3aWR0aCIsImkiLCJub2RlIiwiTm9kZSIsInNwIiwiYWRkQ29tcG9uZW50IiwiU3ByaXRlIiwic3ByaXRlRnJhbWUiLCJwYXJlbnQiLCJhIiwibCIsInYyIiwic2luIiwiUEkiLCJjb3MiLCJzY2FsZSIsInAiLCJwb3NpdGlvbiIsInJ1bkFjdGlvbiIsInNlcXVlbmNlIiwic3Bhd24iLCJtb3ZlQnkiLCJzY2FsZVRvIiwicm90YXRlQnkiLCJmYWRlT3V0IiwiY2FsbEZ1bmMiLCJhY3RpdmUiLCJmIiwiYW5nbGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBTUEsYUFBYSxHQUFHLFNBQWhCQSxhQUFnQixDQUFVQyxDQUFWLEVBQWFDLENBQWIsRUFBZ0I7RUFDbEMsT0FBT0MsSUFBSSxDQUFDQyxLQUFMLENBQVdELElBQUksQ0FBQ0UsTUFBTCxNQUFpQkgsQ0FBQyxHQUFHRCxDQUFyQixJQUEwQkEsQ0FBckMsQ0FBUDtBQUNILENBRkQ7O0FBSUFLLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0VBQ0wsV0FBU0QsRUFBRSxDQUFDRSxTQURQO0VBR0xDLFVBQVUsRUFBRTtJQUNSQyxRQUFRLEVBQUU7TUFDTixXQUFTLElBREg7TUFFTkMsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkgsQ0FERjtJQUtSQyxNQUFNLEVBQUU7TUFDSixXQUFTLElBREw7TUFFSkYsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRkwsQ0FMQTtJQVNSRSxLQUFLLEVBQUU7TUFDSCxXQUFTLElBRE47TUFFSEgsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0lBRk47RUFUQyxDQUhQO0VBa0JMRyxJQWxCSyxnQkFrQkFDLElBbEJBLEVBa0JNO0lBQ1AsS0FBS04sUUFBTCxHQUFnQk0sSUFBSSxDQUFDTixRQUFyQjtJQUNBLEtBQUtHLE1BQUwsR0FBY0csSUFBSSxDQUFDTixRQUFuQjtJQUNBLEtBQUtJLEtBQUwsR0FBYUUsSUFBSSxDQUFDRixLQUFsQjtFQUNILENBdEJJO0VBd0JMO0VBQ0FHLFNBekJLLHFCQXlCS0MsR0F6QkwsRUF5QlVDLEtBekJWLEVBeUJpQjtJQUFBOztJQUFBLDJCQUVUQyxDQUZTO01BR2QsSUFBTUMsSUFBSSxHQUFHLElBQUlmLEVBQUUsQ0FBQ2dCLElBQVAsQ0FBWSxRQUFaLENBQWI7TUFDQSxJQUFNQyxFQUFFLEdBQUdGLElBQUksQ0FBQ0csWUFBTCxDQUFrQmxCLEVBQUUsQ0FBQ21CLE1BQXJCLENBQVg7TUFFQUYsRUFBRSxDQUFDRyxXQUFILEdBQWlCLEtBQUksQ0FBQ2hCLFFBQXRCO01BQ0FXLElBQUksQ0FBQ00sTUFBTCxHQUFjLEtBQUksQ0FBQ04sSUFBbkI7TUFFQSxJQUFNTyxDQUFDLEdBQUcsTUFBTXpCLElBQUksQ0FBQ0UsTUFBTCxFQUFoQjtNQUFBLElBQ0llLENBQUMsR0FBRyxLQUFLakIsSUFBSSxDQUFDRSxNQUFMLEVBQUwsR0FBcUJjLEtBQUssR0FBRyxDQURyQztNQUFBLElBRUlVLENBQUMsR0FBR3ZCLEVBQUUsQ0FBQ3dCLEVBQUgsQ0FBTTNCLElBQUksQ0FBQzRCLEdBQUwsQ0FBU0gsQ0FBQyxHQUFHekIsSUFBSSxDQUFDNkIsRUFBVCxHQUFjLEdBQXZCLElBQThCWixDQUFwQyxFQUF1Q2pCLElBQUksQ0FBQzhCLEdBQUwsQ0FBU0wsQ0FBQyxHQUFHekIsSUFBSSxDQUFDNkIsRUFBVCxHQUFjLEdBQXZCLElBQThCWixDQUFyRSxDQUZSO01BR0FDLElBQUksQ0FBQ2EsS0FBTCxHQUFhLEtBQUsvQixJQUFJLENBQUNFLE1BQUwsRUFBTCxHQUFxQmMsS0FBSyxHQUFHLEdBQTFDO01BQ0EsSUFBTWdCLENBQUMsR0FBRyxLQUFLaEMsSUFBSSxDQUFDRSxNQUFMLEVBQWY7TUFFQWdCLElBQUksQ0FBQ2UsUUFBTCxHQUFnQmxCLEdBQWhCO01BQ0FHLElBQUksQ0FBQ2dCLFNBQUwsQ0FDSS9CLEVBQUUsQ0FBQ2dDLFFBQUgsQ0FBWWhDLEVBQUUsQ0FBQ2lDLEtBQUgsQ0FBU2pDLEVBQUUsQ0FBQ2tDLE1BQUgsQ0FBVUwsQ0FBVixFQUFhTixDQUFiLENBQVQsRUFDUnZCLEVBQUUsQ0FBQ21DLE9BQUgsQ0FBV04sQ0FBQyxHQUFHLEVBQWYsRUFBbUIsRUFBbkIsQ0FEUSxFQUVSN0IsRUFBRSxDQUFDb0MsUUFBSCxDQUFZUCxDQUFDLEdBQUcsRUFBaEIsRUFBb0JuQyxhQUFhLENBQUMsQ0FBQyxHQUFGLEVBQU8sR0FBUCxDQUFqQyxDQUZRLENBQVosRUFHSU0sRUFBRSxDQUFDcUMsT0FBSCxDQUFXLEVBQVgsQ0FISixFQUlJckMsRUFBRSxDQUFDc0MsUUFBSCxDQUFZLFlBQVk7UUFDcEJ2QixJQUFJLENBQUN3QixNQUFMLEdBQWMsS0FBZDtNQUNILENBRkQsRUFFRyxLQUZILENBSkosQ0FESjtJQWhCYzs7SUFDbEI7SUFDQSxLQUFLLElBQUl6QixDQUFDLEdBQUcsQ0FBYixFQUFnQkEsQ0FBQyxHQUFHLEVBQXBCLEVBQXdCLEVBQUVBLENBQTFCLEVBQTZCO01BQUEsTUFBcEJBLENBQW9CO0lBdUI1QixDQXpCaUIsQ0EyQmxCOzs7SUEzQmtCLDZCQTRCVDBCLENBNUJTO01BNkJkLElBQU16QixJQUFJLEdBQUcsSUFBSWYsRUFBRSxDQUFDZ0IsSUFBUCxDQUFZLFFBQVosQ0FBYjtNQUNBLElBQU1DLEVBQUUsR0FBR0YsSUFBSSxDQUFDRyxZQUFMLENBQWtCbEIsRUFBRSxDQUFDbUIsTUFBckIsQ0FBWDtNQUVBRixFQUFFLENBQUNHLFdBQUgsR0FBaUIsS0FBSSxDQUFDYixNQUF0QjtNQUNBUSxJQUFJLENBQUNNLE1BQUwsR0FBYyxLQUFJLENBQUNOLElBQW5CO01BRUEsSUFBSU8sQ0FBQyxHQUFHLE1BQU16QixJQUFJLENBQUNFLE1BQUwsRUFBZDtNQUFBLElBQTZCZSxDQUFDLEdBQUcsS0FBS2pCLElBQUksQ0FBQ0UsTUFBTCxFQUFMLEdBQXFCYyxLQUFLLEdBQUcsQ0FBOUQ7TUFBQSxJQUNJVSxDQUFDLEdBQUd2QixFQUFFLENBQUN3QixFQUFILENBQU0zQixJQUFJLENBQUM0QixHQUFMLENBQVNILENBQUMsR0FBR3pCLElBQUksQ0FBQzZCLEVBQVQsR0FBYyxHQUF2QixJQUE4QlosQ0FBcEMsRUFBdUNqQixJQUFJLENBQUM4QixHQUFMLENBQVNMLENBQUMsR0FBR3pCLElBQUksQ0FBQzZCLEVBQVQsR0FBYyxHQUF2QixJQUE4QlosQ0FBckUsQ0FEUjtNQUVBQyxJQUFJLENBQUNhLEtBQUwsR0FBYSxLQUFLL0IsSUFBSSxDQUFDRSxNQUFMLEVBQUwsR0FBcUJjLEtBQUssR0FBRyxHQUExQztNQUNBLElBQUlnQixDQUFDLEdBQUcsS0FBS2hDLElBQUksQ0FBQ0UsTUFBTCxFQUFiO01BQ0FnQixJQUFJLENBQUNlLFFBQUwsR0FBZ0JsQixHQUFoQjtNQUNBRyxJQUFJLENBQUNnQixTQUFMLENBQWUvQixFQUFFLENBQUNnQyxRQUFILENBQVloQyxFQUFFLENBQUNpQyxLQUFILENBQVNqQyxFQUFFLENBQUNrQyxNQUFILENBQVVMLENBQVYsRUFBYU4sQ0FBYixDQUFULEVBQTBCdkIsRUFBRSxDQUFDbUMsT0FBSCxDQUFXTixDQUFDLEdBQUcsRUFBZixFQUFtQixFQUFuQixDQUExQixDQUFaLEVBQStEN0IsRUFBRSxDQUFDcUMsT0FBSCxDQUFXLEVBQVgsQ0FBL0QsRUFBK0VyQyxFQUFFLENBQUNzQyxRQUFILENBQVksWUFBWTtRQUNsSHZCLElBQUksQ0FBQ3dCLE1BQUwsR0FBYyxLQUFkO01BQ0gsQ0FGNkYsRUFFM0YsS0FGMkYsQ0FBL0UsQ0FBZjtJQXhDYzs7SUE0QmxCLEtBQUssSUFBSUMsQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBRyxFQUFwQixFQUF3QkEsQ0FBQyxFQUF6QixFQUE2QjtNQUFBLE9BQXBCQSxDQUFvQjtJQWU1QixDQTNDaUIsQ0E2Q2xCOzs7SUFDQSxJQUFNekIsSUFBSSxHQUFHLElBQUlmLEVBQUUsQ0FBQ2dCLElBQVAsQ0FBWSxRQUFaLENBQWI7SUFDQSxJQUFNQyxFQUFFLEdBQUdGLElBQUksQ0FBQ0csWUFBTCxDQUFrQmxCLEVBQUUsQ0FBQ21CLE1BQXJCLENBQVg7SUFFQUYsRUFBRSxDQUFDRyxXQUFILEdBQWlCLEtBQUtaLEtBQXRCO0lBQ0FPLElBQUksQ0FBQ00sTUFBTCxHQUFjLEtBQUtOLElBQW5CO0lBRUFBLElBQUksQ0FBQ2UsUUFBTCxHQUFnQmxCLEdBQWhCO0lBQ0FHLElBQUksQ0FBQ2EsS0FBTCxHQUFhLENBQWI7SUFDQWIsSUFBSSxDQUFDMEIsS0FBTCxHQUFhL0MsYUFBYSxDQUFDLENBQUQsRUFBSSxHQUFKLENBQTFCO0lBQ0FxQixJQUFJLENBQUNnQixTQUFMLENBQWUvQixFQUFFLENBQUNnQyxRQUFILENBQVloQyxFQUFFLENBQUNpQyxLQUFILENBQVNqQyxFQUFFLENBQUNtQyxPQUFILENBQVcsRUFBWCxFQUFldEIsS0FBSyxHQUFHLEdBQXZCLENBQVQsRUFBc0NiLEVBQUUsQ0FBQ3FDLE9BQUgsQ0FBVyxDQUFYLENBQXRDLENBQVosRUFBa0VyQyxFQUFFLENBQUNzQyxRQUFILENBQVksWUFBWTtNQUNyR3ZCLElBQUksQ0FBQ3dCLE1BQUwsR0FBYyxLQUFkO0lBQ0gsQ0FGZ0YsQ0FBbEUsQ0FBZjtFQUdIO0FBbkZJLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNvbnN0IFJhbmRvbUludGVnZXIgPSBmdW5jdGlvbiAoZSwgdCkge1xuICAgIHJldHVybiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAodCAtIGUpICsgZSlcbn1cblxuY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgcGFydGljbGU6IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBjaXJjbGU6IHtcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZVxuICAgICAgICB9LFxuICAgICAgICBzbGFzaDoge1xuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcbiAgICAgICAgICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lXG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgaW5pdChkYXRhKSB7XG4gICAgICAgIHRoaXMucGFydGljbGUgPSBkYXRhLnBhcnRpY2xlXG4gICAgICAgIHRoaXMuY2lyY2xlID0gZGF0YS5wYXJ0aWNsZVxuICAgICAgICB0aGlzLnNsYXNoID0gZGF0YS5zbGFzaFxuICAgIH0sXG5cbiAgICAvLyDlkIjlubbml7bnmoTliqjnlLvmlYjmnpxcbiAgICBzaG93SnVpY2UocG9zLCB3aWR0aCkge1xuICAgICAgICAvLyDmnpznspJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCAxMDsgKytpKSB7XG4gICAgICAgICAgICBjb25zdCBub2RlID0gbmV3IGNjLk5vZGUoJ1Nwcml0ZScpO1xuICAgICAgICAgICAgY29uc3Qgc3AgPSBub2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuXG4gICAgICAgICAgICBzcC5zcHJpdGVGcmFtZSA9IHRoaXMucGFydGljbGU7XG4gICAgICAgICAgICBub2RlLnBhcmVudCA9IHRoaXMubm9kZTtcblxuICAgICAgICAgICAgY29uc3QgYSA9IDM1OSAqIE1hdGgucmFuZG9tKCksXG4gICAgICAgICAgICAgICAgaSA9IDMwICogTWF0aC5yYW5kb20oKSArIHdpZHRoIC8gMixcbiAgICAgICAgICAgICAgICBsID0gY2MudjIoTWF0aC5zaW4oYSAqIE1hdGguUEkgLyAxODApICogaSwgTWF0aC5jb3MoYSAqIE1hdGguUEkgLyAxODApICogaSk7XG4gICAgICAgICAgICBub2RlLnNjYWxlID0gLjUgKiBNYXRoLnJhbmRvbSgpICsgd2lkdGggLyAxMDA7XG4gICAgICAgICAgICBjb25zdCBwID0gLjUgKiBNYXRoLnJhbmRvbSgpO1xuXG4gICAgICAgICAgICBub2RlLnBvc2l0aW9uID0gcG9zO1xuICAgICAgICAgICAgbm9kZS5ydW5BY3Rpb24oXG4gICAgICAgICAgICAgICAgY2Muc2VxdWVuY2UoY2Muc3Bhd24oY2MubW92ZUJ5KHAsIGwpLFxuICAgICAgICAgICAgICAgICAgICBjYy5zY2FsZVRvKHAgKyAuNSwgLjMpLFxuICAgICAgICAgICAgICAgICAgICBjYy5yb3RhdGVCeShwICsgLjUsIFJhbmRvbUludGVnZXIoLTM2MCwgMzYwKSkpLFxuICAgICAgICAgICAgICAgICAgICBjYy5mYWRlT3V0KC4xKSxcbiAgICAgICAgICAgICAgICAgICAgY2MuY2FsbEZ1bmMoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbm9kZS5hY3RpdmUgPSBmYWxzZVxuICAgICAgICAgICAgICAgICAgICB9LCB0aGlzKSlcbiAgICAgICAgICAgIClcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIOawtOePoFxuICAgICAgICBmb3IgKGxldCBmID0gMDsgZiA8IDIwOyBmKyspIHtcbiAgICAgICAgICAgIGNvbnN0IG5vZGUgPSBuZXcgY2MuTm9kZSgnU3ByaXRlJyk7XG4gICAgICAgICAgICBjb25zdCBzcCA9IG5vZGUuYWRkQ29tcG9uZW50KGNjLlNwcml0ZSk7XG5cbiAgICAgICAgICAgIHNwLnNwcml0ZUZyYW1lID0gdGhpcy5jaXJjbGU7XG4gICAgICAgICAgICBub2RlLnBhcmVudCA9IHRoaXMubm9kZTtcblxuICAgICAgICAgICAgbGV0IGEgPSAzNTkgKiBNYXRoLnJhbmRvbSgpLCBpID0gMzAgKiBNYXRoLnJhbmRvbSgpICsgd2lkdGggLyAyLFxuICAgICAgICAgICAgICAgIGwgPSBjYy52MihNYXRoLnNpbihhICogTWF0aC5QSSAvIDE4MCkgKiBpLCBNYXRoLmNvcyhhICogTWF0aC5QSSAvIDE4MCkgKiBpKTtcbiAgICAgICAgICAgIG5vZGUuc2NhbGUgPSAuNSAqIE1hdGgucmFuZG9tKCkgKyB3aWR0aCAvIDEwMDtcbiAgICAgICAgICAgIGxldCBwID0gLjUgKiBNYXRoLnJhbmRvbSgpO1xuICAgICAgICAgICAgbm9kZS5wb3NpdGlvbiA9IHBvc1xuICAgICAgICAgICAgbm9kZS5ydW5BY3Rpb24oY2Muc2VxdWVuY2UoY2Muc3Bhd24oY2MubW92ZUJ5KHAsIGwpLCBjYy5zY2FsZVRvKHAgKyAuNSwgLjMpKSwgY2MuZmFkZU91dCguMSksIGNjLmNhbGxGdW5jKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBub2RlLmFjdGl2ZSA9IGZhbHNlXG4gICAgICAgICAgICB9LCB0aGlzKSkpXG4gICAgICAgIH1cblxuICAgICAgICAvLyDmnpzmsYFcbiAgICAgICAgY29uc3Qgbm9kZSA9IG5ldyBjYy5Ob2RlKCdTcHJpdGUnKTtcbiAgICAgICAgY29uc3Qgc3AgPSBub2RlLmFkZENvbXBvbmVudChjYy5TcHJpdGUpO1xuXG4gICAgICAgIHNwLnNwcml0ZUZyYW1lID0gdGhpcy5zbGFzaDtcbiAgICAgICAgbm9kZS5wYXJlbnQgPSB0aGlzLm5vZGU7XG5cbiAgICAgICAgbm9kZS5wb3NpdGlvbiA9IHBvc1xuICAgICAgICBub2RlLnNjYWxlID0gMFxuICAgICAgICBub2RlLmFuZ2xlID0gUmFuZG9tSW50ZWdlcigwLCAzNjApXG4gICAgICAgIG5vZGUucnVuQWN0aW9uKGNjLnNlcXVlbmNlKGNjLnNwYXduKGNjLnNjYWxlVG8oLjIsIHdpZHRoIC8gMTUwKSwgY2MuZmFkZU91dCgxKSksIGNjLmNhbGxGdW5jKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIG5vZGUuYWN0aXZlID0gZmFsc2VcbiAgICAgICAgfSkpKVxuICAgIH0sXG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/end.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f5d1cWqNEZCtZBXic8+4t+/', 'end');
// scripts/end.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  toEnd: function toEnd(e, c) {
    cc.game.end();
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcZW5kLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwidG9FbmQiLCJlIiwiYyIsImdhbWUiLCJlbmQiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7RUFDTCxXQUFTRCxFQUFFLENBQUNFLFNBRFA7RUFHTEMsVUFBVSxFQUFFLEVBSFA7RUFPTEMsS0FQSyxpQkFPQ0MsQ0FQRCxFQU9HQyxDQVBILEVBT0s7SUFDVk4sRUFBRSxDQUFDTyxJQUFILENBQVFDLEdBQVI7RUFDSCxDQVRRO0VBV0xDLEtBWEssbUJBV0ksQ0FFUixDQWJJLENBZUw7O0FBZkssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiXG5jYy5DbGFzcyh7XG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxuXG4gICAgcHJvcGVydGllczoge1xuICAgICBcbiAgICB9LFxuXG4gICAgdG9FbmQoZSxjKXtcbiAgICBjYy5nYW1lLmVuZCgpO1xufSxcblxuICAgIHN0YXJ0ICgpIHtcblxuICAgIH0sXG5cbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcbn0pO1xuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Fruit.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '365b4UAiQRBA7QXa2IuFMmj', 'Fruit');
// scripts/Fruit.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    id: 0,
    collisionEndY: -1000,
    deadlineY: 310
  },
  init: function init(data) {
    this.id = data.id;
    var sp = this.node.getComponent(cc.Sprite);
    sp.spriteFrame = data.iconSF;
  },
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log("触发碰撞检测");
    console.log("碰撞物体: ", other.node.name); // 如果碰撞物体是 'dead_line'，我们不需要在这里做特殊处理，因为我们在 onCollisionExit 中处理
  },
  onCollisionExit: function onCollisionExit(other, self) {
    if (other.node.name === 'dead_line') {
      // 记录碰撞结束时的 y 坐标（水果的底部中点）
      this.collisionEndY = this.node.y;
      console.log("y坐标", this.node.y);
    }
  },
  update: function update(dt) {
    // 使用 this 关键字来访问类的属性
    if (this.collisionEndY >= this.deadlineY) {
      console.log("水果在碰撞结束后超过了死区，游戏结束");
      cc.director.loadScene('end'); // 加载结束场景
    }
  },
  onBeginContact: function onBeginContact(contact, self, other) {
    if (self.node && other.node) {
      var s = self.node.getComponent('Fruit');
      var o = other.node.getComponent('Fruit');

      if (s && o && s.id === o.id) {
        self.node.emit('sameContact', {
          self: self,
          other: other
        });
      }
    }
  } // 注意：onBeginContact 不是 Cocos Creator 标准物理回调方法
  // 如果您想要处理两个水果之间的相同 ID 碰撞，您可能需要使用其他方法
  // 比如，在 onCollisionEnter 中检查两个水果的 ID，并设置一个标志位或触发一个事件
  // 这里我们移除了 onBeginContact 方法，因为它不是物理系统的一部分

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcRnJ1aXQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJpZCIsImNvbGxpc2lvbkVuZFkiLCJkZWFkbGluZVkiLCJpbml0IiwiZGF0YSIsInNwIiwibm9kZSIsImdldENvbXBvbmVudCIsIlNwcml0ZSIsInNwcml0ZUZyYW1lIiwiaWNvblNGIiwic3RhcnQiLCJvbkNvbGxpc2lvbkVudGVyIiwib3RoZXIiLCJzZWxmIiwiY29uc29sZSIsImxvZyIsIm5hbWUiLCJvbkNvbGxpc2lvbkV4aXQiLCJ5IiwidXBkYXRlIiwiZHQiLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsIm9uQmVnaW5Db250YWN0IiwiY29udGFjdCIsInMiLCJvIiwiZW1pdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7RUFDTCxXQUFTRCxFQUFFLENBQUNFLFNBRFA7RUFHTEMsVUFBVSxFQUFFO0lBQ1JDLEVBQUUsRUFBRSxDQURJO0lBRVJDLGFBQWEsRUFBRSxDQUFDLElBRlI7SUFHUkMsU0FBUyxFQUFFO0VBSEgsQ0FIUDtFQVNMQyxJQVRLLGdCQVNBQyxJQVRBLEVBU007SUFDUCxLQUFLSixFQUFMLEdBQVVJLElBQUksQ0FBQ0osRUFBZjtJQUNBLElBQU1LLEVBQUUsR0FBRyxLQUFLQyxJQUFMLENBQVVDLFlBQVYsQ0FBdUJYLEVBQUUsQ0FBQ1ksTUFBMUIsQ0FBWDtJQUNBSCxFQUFFLENBQUNJLFdBQUgsR0FBaUJMLElBQUksQ0FBQ00sTUFBdEI7RUFDSCxDQWJJO0VBZUxDLEtBZkssbUJBZUcsQ0FDUCxDQWhCSTtFQWtCTEMsZ0JBbEJLLDRCQWtCWUMsS0FsQlosRUFrQm1CQyxJQWxCbkIsRUFrQnlCO0lBQzFCQyxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0lBQ0FELE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBc0JILEtBQUssQ0FBQ1AsSUFBTixDQUFXVyxJQUFqQyxFQUYwQixDQUkxQjtFQUNILENBdkJJO0VBeUJMQyxlQXpCSywyQkF5QldMLEtBekJYLEVBeUJrQkMsSUF6QmxCLEVBeUJ3QjtJQUN6QixJQUFJRCxLQUFLLENBQUNQLElBQU4sQ0FBV1csSUFBWCxLQUFvQixXQUF4QixFQUFxQztNQUNqQztNQUNBLEtBQUtoQixhQUFMLEdBQXFCLEtBQUtLLElBQUwsQ0FBVWEsQ0FBL0I7TUFDQUosT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQixLQUFLVixJQUFMLENBQVVhLENBQTVCO0lBQ0g7RUFDSixDQS9CSTtFQWlDTEMsTUFqQ0ssa0JBaUNFQyxFQWpDRixFQWlDTTtJQUNQO0lBQ0EsSUFBSSxLQUFLcEIsYUFBTCxJQUFzQixLQUFLQyxTQUEvQixFQUEwQztNQUN0Q2EsT0FBTyxDQUFDQyxHQUFSLENBQVksb0JBQVo7TUFDQXBCLEVBQUUsQ0FBQzBCLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixLQUF0QixFQUZzQyxDQUVSO0lBQ2pDO0VBQ0osQ0F2Q0k7RUF3Q0xDLGNBeENLLDBCQXdDVUMsT0F4Q1YsRUF3Q21CWCxJQXhDbkIsRUF3Q3lCRCxLQXhDekIsRUF3Q2dDO0lBQ2pDLElBQUlDLElBQUksQ0FBQ1IsSUFBTCxJQUFhTyxLQUFLLENBQUNQLElBQXZCLEVBQTZCO01BQ3pCLElBQU1vQixDQUFDLEdBQUdaLElBQUksQ0FBQ1IsSUFBTCxDQUFVQyxZQUFWLENBQXVCLE9BQXZCLENBQVY7TUFDQSxJQUFNb0IsQ0FBQyxHQUFHZCxLQUFLLENBQUNQLElBQU4sQ0FBV0MsWUFBWCxDQUF3QixPQUF4QixDQUFWOztNQUNBLElBQUltQixDQUFDLElBQUlDLENBQUwsSUFBVUQsQ0FBQyxDQUFDMUIsRUFBRixLQUFTMkIsQ0FBQyxDQUFDM0IsRUFBekIsRUFBNkI7UUFDekJjLElBQUksQ0FBQ1IsSUFBTCxDQUFVc0IsSUFBVixDQUFlLGFBQWYsRUFBOEI7VUFBQ2QsSUFBSSxFQUFKQSxJQUFEO1VBQU9ELEtBQUssRUFBTEE7UUFBUCxDQUE5QjtNQUNIO0lBQ0o7RUFDSixDQWhESSxDQWlETDtFQUNBO0VBQ0E7RUFDQTs7QUFwREssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgaWQ6IDAsXG4gICAgICAgIGNvbGxpc2lvbkVuZFk6IC0xMDAwLFxuICAgICAgICBkZWFkbGluZVk6IDMxMCxcbiAgICB9LFxuXG4gICAgaW5pdChkYXRhKSB7XG4gICAgICAgIHRoaXMuaWQgPSBkYXRhLmlkO1xuICAgICAgICBjb25zdCBzcCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgc3Auc3ByaXRlRnJhbWUgPSBkYXRhLmljb25TRjtcbiAgICB9LFxuXG4gICAgc3RhcnQoKSB7XG4gICAgfSxcblxuICAgIG9uQ29sbGlzaW9uRW50ZXIob3RoZXIsIHNlbGYpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCLop6blj5HnorDmkp7mo4DmtYtcIik7XG4gICAgICAgIGNvbnNvbGUubG9nKFwi56Kw5pKe54mp5L2TOiBcIiwgb3RoZXIubm9kZS5uYW1lKTtcblxuICAgICAgICAvLyDlpoLmnpznorDmkp7niankvZPmmK8gJ2RlYWRfbGluZSfvvIzmiJHku6zkuI3pnIDopoHlnKjov5nph4zlgZrnibnmrorlpITnkIbvvIzlm6DkuLrmiJHku6zlnKggb25Db2xsaXNpb25FeGl0IOS4reWkhOeQhlxuICAgIH0sXG5cbiAgICBvbkNvbGxpc2lvbkV4aXQob3RoZXIsIHNlbGYpIHtcbiAgICAgICAgaWYgKG90aGVyLm5vZGUubmFtZSA9PT0gJ2RlYWRfbGluZScpIHtcbiAgICAgICAgICAgIC8vIOiusOW9leeisOaSnue7k+adn+aXtueahCB5IOWdkOagh++8iOawtOaenOeahOW6lemDqOS4reeCue+8iVxuICAgICAgICAgICAgdGhpcy5jb2xsaXNpb25FbmRZID0gdGhpcy5ub2RlLnk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInnlnZDmoIdcIix0aGlzLm5vZGUueSk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgdXBkYXRlKGR0KSB7XG4gICAgICAgIC8vIOS9v+eUqCB0aGlzIOWFs+mUruWtl+adpeiuv+mXruexu+eahOWxnuaAp1xuICAgICAgICBpZiAodGhpcy5jb2xsaXNpb25FbmRZID49IHRoaXMuZGVhZGxpbmVZKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuawtOaenOWcqOeisOaSnue7k+adn+WQjui2hei/h+S6huatu+WMuu+8jOa4uOaIj+e7k+adn1wiKTtcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnZW5kJyk7IC8vIOWKoOi9vee7k+adn+WcuuaZr1xuICAgICAgICB9XG4gICAgfSxcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmLCBvdGhlcikgeyAgXG4gICAgICAgIGlmIChzZWxmLm5vZGUgJiYgb3RoZXIubm9kZSkgeyAgXG4gICAgICAgICAgICBjb25zdCBzID0gc2VsZi5ub2RlLmdldENvbXBvbmVudCgnRnJ1aXQnKTsgIFxuICAgICAgICAgICAgY29uc3QgbyA9IG90aGVyLm5vZGUuZ2V0Q29tcG9uZW50KCdGcnVpdCcpOyAgXG4gICAgICAgICAgICBpZiAocyAmJiBvICYmIHMuaWQgPT09IG8uaWQpIHsgIFxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5lbWl0KCdzYW1lQ29udGFjdCcsIHtzZWxmLCBvdGhlcn0pOyAgXG4gICAgICAgICAgICB9ICBcbiAgICAgICAgfSAgXG4gICAgfSwgIFxuICAgIC8vIOazqOaEj++8mm9uQmVnaW5Db250YWN0IOS4jeaYryBDb2NvcyBDcmVhdG9yIOagh+WHhueJqeeQhuWbnuiwg+aWueazlVxuICAgIC8vIOWmguaenOaCqOaDs+imgeWkhOeQhuS4pOS4quawtOaenOS5i+mXtOeahOebuOWQjCBJRCDnorDmkp7vvIzmgqjlj6/og73pnIDopoHkvb/nlKjlhbbku5bmlrnms5VcbiAgICAvLyDmr5TlpoLvvIzlnKggb25Db2xsaXNpb25FbnRlciDkuK3mo4Dmn6XkuKTkuKrmsLTmnpznmoQgSUTvvIzlubborr7nva7kuIDkuKrmoIflv5fkvY3miJbop6blj5HkuIDkuKrkuovku7ZcbiAgICAvLyDov5nph4zmiJHku6znp7vpmaTkuoYgb25CZWdpbkNvbnRhY3Qg5pa55rOV77yM5Zug5Li65a6D5LiN5piv54mp55CG57O757uf55qE5LiA6YOo5YiGXG59KTsiXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/start.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '0bd07rRcCBHHrkRKdaLZkSQ', 'start');
// scripts/start.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // 点击事件回调函数
  toStart: function toStart(e, c) {
    cc.director.loadScene('game');
  },
  start: function start() {}
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcc3RhcnQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJ0b1N0YXJ0IiwiZSIsImMiLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztFQUNMLFdBQVNELEVBQUUsQ0FBQ0UsU0FEUDtFQUdMQyxVQUFVLEVBQUUsRUFIUDtFQU9MO0VBQ0FDLE9BUkssbUJBUUdDLENBUkgsRUFRTUMsQ0FSTixFQVFRO0lBRVROLEVBQUUsQ0FBQ08sUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0VBQ0gsQ0FYSTtFQWFMQyxLQWJLLG1CQWFJLENBR1o7QUFoQlEsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcblxuICAgIH0sXG5cbiAgICAvLyDngrnlh7vkuovku7blm57osIPlh73mlbBcbiAgICB0b1N0YXJ0KGUsIGMpe1xuXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnZ2FtZScpXG4gICAgfSxcblxuICAgIHN0YXJ0ICgpIHtcblxuXG59XG59KTtcbiJdfQ==
//------QC-SOURCE-SPLIT------
