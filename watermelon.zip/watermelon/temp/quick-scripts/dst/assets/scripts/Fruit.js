
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/scripts/Fruit.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '365b4UAiQRBA7QXa2IuFMmj', 'Fruit');
// scripts/Fruit.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    id: 0,
    collisionEndY: -1000,
    deadlineY: 310
  },
  init: function init(data) {
    this.id = data.id;
    var sp = this.node.getComponent(cc.Sprite);
    sp.spriteFrame = data.iconSF;
  },
  start: function start() {},
  onCollisionEnter: function onCollisionEnter(other, self) {
    console.log("触发碰撞检测");
    console.log("碰撞物体: ", other.node.name); // 如果碰撞物体是 'dead_line'，我们不需要在这里做特殊处理，因为我们在 onCollisionExit 中处理
  },
  onCollisionExit: function onCollisionExit(other, self) {
    if (other.node.name === 'dead_line') {
      // 记录碰撞结束时的 y 坐标（水果的底部中点）
      this.collisionEndY = this.node.y;
      console.log("y坐标", this.node.y);
    }
  },
  update: function update(dt) {
    // 使用 this 关键字来访问类的属性
    if (this.collisionEndY >= this.deadlineY) {
      console.log("水果在碰撞结束后超过了死区，游戏结束");
      cc.director.loadScene('end'); // 加载结束场景
    }
  },
  onBeginContact: function onBeginContact(contact, self, other) {
    if (self.node && other.node) {
      var s = self.node.getComponent('Fruit');
      var o = other.node.getComponent('Fruit');

      if (s && o && s.id === o.id) {
        self.node.emit('sameContact', {
          self: self,
          other: other
        });
      }
    }
  } // 注意：onBeginContact 不是 Cocos Creator 标准物理回调方法
  // 如果您想要处理两个水果之间的相同 ID 碰撞，您可能需要使用其他方法
  // 比如，在 onCollisionEnter 中检查两个水果的 ID，并设置一个标志位或触发一个事件
  // 这里我们移除了 onBeginContact 方法，因为它不是物理系统的一部分

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcc2NyaXB0c1xcRnJ1aXQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJpZCIsImNvbGxpc2lvbkVuZFkiLCJkZWFkbGluZVkiLCJpbml0IiwiZGF0YSIsInNwIiwibm9kZSIsImdldENvbXBvbmVudCIsIlNwcml0ZSIsInNwcml0ZUZyYW1lIiwiaWNvblNGIiwic3RhcnQiLCJvbkNvbGxpc2lvbkVudGVyIiwib3RoZXIiLCJzZWxmIiwiY29uc29sZSIsImxvZyIsIm5hbWUiLCJvbkNvbGxpc2lvbkV4aXQiLCJ5IiwidXBkYXRlIiwiZHQiLCJkaXJlY3RvciIsImxvYWRTY2VuZSIsIm9uQmVnaW5Db250YWN0IiwiY29udGFjdCIsInMiLCJvIiwiZW1pdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7RUFDTCxXQUFTRCxFQUFFLENBQUNFLFNBRFA7RUFHTEMsVUFBVSxFQUFFO0lBQ1JDLEVBQUUsRUFBRSxDQURJO0lBRVJDLGFBQWEsRUFBRSxDQUFDLElBRlI7SUFHUkMsU0FBUyxFQUFFO0VBSEgsQ0FIUDtFQVNMQyxJQVRLLGdCQVNBQyxJQVRBLEVBU007SUFDUCxLQUFLSixFQUFMLEdBQVVJLElBQUksQ0FBQ0osRUFBZjtJQUNBLElBQU1LLEVBQUUsR0FBRyxLQUFLQyxJQUFMLENBQVVDLFlBQVYsQ0FBdUJYLEVBQUUsQ0FBQ1ksTUFBMUIsQ0FBWDtJQUNBSCxFQUFFLENBQUNJLFdBQUgsR0FBaUJMLElBQUksQ0FBQ00sTUFBdEI7RUFDSCxDQWJJO0VBZUxDLEtBZkssbUJBZUcsQ0FDUCxDQWhCSTtFQWtCTEMsZ0JBbEJLLDRCQWtCWUMsS0FsQlosRUFrQm1CQyxJQWxCbkIsRUFrQnlCO0lBQzFCQyxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0lBQ0FELE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVosRUFBc0JILEtBQUssQ0FBQ1AsSUFBTixDQUFXVyxJQUFqQyxFQUYwQixDQUkxQjtFQUNILENBdkJJO0VBeUJMQyxlQXpCSywyQkF5QldMLEtBekJYLEVBeUJrQkMsSUF6QmxCLEVBeUJ3QjtJQUN6QixJQUFJRCxLQUFLLENBQUNQLElBQU4sQ0FBV1csSUFBWCxLQUFvQixXQUF4QixFQUFxQztNQUNqQztNQUNBLEtBQUtoQixhQUFMLEdBQXFCLEtBQUtLLElBQUwsQ0FBVWEsQ0FBL0I7TUFDQUosT0FBTyxDQUFDQyxHQUFSLENBQVksS0FBWixFQUFrQixLQUFLVixJQUFMLENBQVVhLENBQTVCO0lBQ0g7RUFDSixDQS9CSTtFQWlDTEMsTUFqQ0ssa0JBaUNFQyxFQWpDRixFQWlDTTtJQUNQO0lBQ0EsSUFBSSxLQUFLcEIsYUFBTCxJQUFzQixLQUFLQyxTQUEvQixFQUEwQztNQUN0Q2EsT0FBTyxDQUFDQyxHQUFSLENBQVksb0JBQVo7TUFDQXBCLEVBQUUsQ0FBQzBCLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixLQUF0QixFQUZzQyxDQUVSO0lBQ2pDO0VBQ0osQ0F2Q0k7RUF3Q0xDLGNBeENLLDBCQXdDVUMsT0F4Q1YsRUF3Q21CWCxJQXhDbkIsRUF3Q3lCRCxLQXhDekIsRUF3Q2dDO0lBQ2pDLElBQUlDLElBQUksQ0FBQ1IsSUFBTCxJQUFhTyxLQUFLLENBQUNQLElBQXZCLEVBQTZCO01BQ3pCLElBQU1vQixDQUFDLEdBQUdaLElBQUksQ0FBQ1IsSUFBTCxDQUFVQyxZQUFWLENBQXVCLE9BQXZCLENBQVY7TUFDQSxJQUFNb0IsQ0FBQyxHQUFHZCxLQUFLLENBQUNQLElBQU4sQ0FBV0MsWUFBWCxDQUF3QixPQUF4QixDQUFWOztNQUNBLElBQUltQixDQUFDLElBQUlDLENBQUwsSUFBVUQsQ0FBQyxDQUFDMUIsRUFBRixLQUFTMkIsQ0FBQyxDQUFDM0IsRUFBekIsRUFBNkI7UUFDekJjLElBQUksQ0FBQ1IsSUFBTCxDQUFVc0IsSUFBVixDQUFlLGFBQWYsRUFBOEI7VUFBQ2QsSUFBSSxFQUFKQSxJQUFEO1VBQU9ELEtBQUssRUFBTEE7UUFBUCxDQUE5QjtNQUNIO0lBQ0o7RUFDSixDQWhESSxDQWlETDtFQUNBO0VBQ0E7RUFDQTs7QUFwREssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcblxuICAgIHByb3BlcnRpZXM6IHtcbiAgICAgICAgaWQ6IDAsXG4gICAgICAgIGNvbGxpc2lvbkVuZFk6IC0xMDAwLFxuICAgICAgICBkZWFkbGluZVk6IDMxMCxcbiAgICB9LFxuXG4gICAgaW5pdChkYXRhKSB7XG4gICAgICAgIHRoaXMuaWQgPSBkYXRhLmlkO1xuICAgICAgICBjb25zdCBzcCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKTtcbiAgICAgICAgc3Auc3ByaXRlRnJhbWUgPSBkYXRhLmljb25TRjtcbiAgICB9LFxuXG4gICAgc3RhcnQoKSB7XG4gICAgfSxcblxuICAgIG9uQ29sbGlzaW9uRW50ZXIob3RoZXIsIHNlbGYpIHtcbiAgICAgICAgY29uc29sZS5sb2coXCLop6blj5HnorDmkp7mo4DmtYtcIik7XG4gICAgICAgIGNvbnNvbGUubG9nKFwi56Kw5pKe54mp5L2TOiBcIiwgb3RoZXIubm9kZS5uYW1lKTtcblxuICAgICAgICAvLyDlpoLmnpznorDmkp7niankvZPmmK8gJ2RlYWRfbGluZSfvvIzmiJHku6zkuI3pnIDopoHlnKjov5nph4zlgZrnibnmrorlpITnkIbvvIzlm6DkuLrmiJHku6zlnKggb25Db2xsaXNpb25FeGl0IOS4reWkhOeQhlxuICAgIH0sXG5cbiAgICBvbkNvbGxpc2lvbkV4aXQob3RoZXIsIHNlbGYpIHtcbiAgICAgICAgaWYgKG90aGVyLm5vZGUubmFtZSA9PT0gJ2RlYWRfbGluZScpIHtcbiAgICAgICAgICAgIC8vIOiusOW9leeisOaSnue7k+adn+aXtueahCB5IOWdkOagh++8iOawtOaenOeahOW6lemDqOS4reeCue+8iVxuICAgICAgICAgICAgdGhpcy5jb2xsaXNpb25FbmRZID0gdGhpcy5ub2RlLnk7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInnlnZDmoIdcIix0aGlzLm5vZGUueSk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgdXBkYXRlKGR0KSB7XG4gICAgICAgIC8vIOS9v+eUqCB0aGlzIOWFs+mUruWtl+adpeiuv+mXruexu+eahOWxnuaAp1xuICAgICAgICBpZiAodGhpcy5jb2xsaXNpb25FbmRZID49IHRoaXMuZGVhZGxpbmVZKSB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcIuawtOaenOWcqOeisOaSnue7k+adn+WQjui2hei/h+S6huatu+WMuu+8jOa4uOaIj+e7k+adn1wiKTtcbiAgICAgICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZSgnZW5kJyk7IC8vIOWKoOi9vee7k+adn+WcuuaZr1xuICAgICAgICB9XG4gICAgfSxcbiAgICBvbkJlZ2luQ29udGFjdChjb250YWN0LCBzZWxmLCBvdGhlcikgeyAgXG4gICAgICAgIGlmIChzZWxmLm5vZGUgJiYgb3RoZXIubm9kZSkgeyAgXG4gICAgICAgICAgICBjb25zdCBzID0gc2VsZi5ub2RlLmdldENvbXBvbmVudCgnRnJ1aXQnKTsgIFxuICAgICAgICAgICAgY29uc3QgbyA9IG90aGVyLm5vZGUuZ2V0Q29tcG9uZW50KCdGcnVpdCcpOyAgXG4gICAgICAgICAgICBpZiAocyAmJiBvICYmIHMuaWQgPT09IG8uaWQpIHsgIFxuICAgICAgICAgICAgICAgIHNlbGYubm9kZS5lbWl0KCdzYW1lQ29udGFjdCcsIHtzZWxmLCBvdGhlcn0pOyAgXG4gICAgICAgICAgICB9ICBcbiAgICAgICAgfSAgXG4gICAgfSwgIFxuICAgIC8vIOazqOaEj++8mm9uQmVnaW5Db250YWN0IOS4jeaYryBDb2NvcyBDcmVhdG9yIOagh+WHhueJqeeQhuWbnuiwg+aWueazlVxuICAgIC8vIOWmguaenOaCqOaDs+imgeWkhOeQhuS4pOS4quawtOaenOS5i+mXtOeahOebuOWQjCBJRCDnorDmkp7vvIzmgqjlj6/og73pnIDopoHkvb/nlKjlhbbku5bmlrnms5VcbiAgICAvLyDmr5TlpoLvvIzlnKggb25Db2xsaXNpb25FbnRlciDkuK3mo4Dmn6XkuKTkuKrmsLTmnpznmoQgSUTvvIzlubborr7nva7kuIDkuKrmoIflv5fkvY3miJbop6blj5HkuIDkuKrkuovku7ZcbiAgICAvLyDov5nph4zmiJHku6znp7vpmaTkuoYgb25CZWdpbkNvbnRhY3Qg5pa55rOV77yM5Zug5Li65a6D5LiN5piv54mp55CG57O757uf55qE5LiA6YOo5YiGXG59KTsiXX0=